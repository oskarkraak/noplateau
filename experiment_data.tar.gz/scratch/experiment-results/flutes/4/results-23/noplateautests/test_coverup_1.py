# file: flutes.math.py:6-8
# asked: {"lines": [6, 8], "branches": []}
# gained: {"lines": [6, 8], "branches": []}

import pytest
from flutes.math import ceil_div

def test_ceil_div_positive_numbers():
    assert ceil_div(5, 2) == 3
    assert ceil_div(10, 3) == 4

def test_ceil_div_negative_numbers():
    assert ceil_div(-5, 2) == -2
    assert ceil_div(-10, 3) == -3

def test_ceil_div_zero_divisor():
    with pytest.raises(ZeroDivisionError):
        ceil_div(5, 0)

def test_ceil_div_zero_numerator():
    assert ceil_div(0, 1) == 0
    assert ceil_div(0, 2) == 0
    assert ceil_div(0, 3) == 0
