# file: flutes.math.py:6-8
# asked: {"lines": [6, 8], "branches": []}
# gained: {"lines": [6, 8], "branches": []}

import pytest
from flutes.math import ceil_div

def test_ceil_div_positive_numbers():
    assert ceil_div(5, 2) == 3
    assert ceil_div(10, 3) == 4

def test_ceil_div_edge_cases():
    assert ceil_div(0, 1) == 0
    assert ceil_div(1, 1) == 1

def test_ceil_div_large_numbers():
    assert ceil_div(1000000, 3) == 333334
    assert ceil_div(999999, 3) == 333333

def test_ceil_div_negative_numbers():
    assert ceil_div(-5, 2) == -2
    assert ceil_div(-10, 3) == -3

def test_ceil_div_division_by_one():
    assert ceil_div(5, 1) == 5
    assert ceil_div(-5, 1) == -5
