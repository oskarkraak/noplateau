# file: blib2to3/blib2to3.pgen2.literals.py:25-44
# asked: {"lines": [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44], "branches": [[29, 30], [29, 31], [31, 32], [31, 40], [33, 34], [33, 35]]}
# gained: {"lines": [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44], "branches": [[29, 30], [29, 31], [31, 32], [31, 40], [33, 34], [33, 35]]}

import pytest
import re
from blib2to3.pgen2.literals import escape

simple_escapes = {
    'n': '\n',
    't': '\t',
    # Add other simple escapes as needed
}

@pytest.fixture
def mock_match():
    class MockMatch:
        def group(self, *args):
            return self.groups

    return MockMatch()

def test_escape_simple_escape(mock_match):
    mock_match.groups = ('\\n', 'n')
    result = escape(mock_match)
    assert result == simple_escapes['n']

def test_escape_hex_escape_valid(mock_match):
    mock_match.groups = ('\\x41', 'x41')
    result = escape(mock_match)
    assert result == 'A'  # ASCII for 65

def test_escape_hex_escape_invalid_length(mock_match):
    mock_match.groups = ('\\x4', 'x4')
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(mock_match)

def test_escape_hex_escape_invalid_value(mock_match):
    mock_match.groups = ('\\xG1', 'xG1')
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(mock_match)

def test_escape_octal_escape_valid(mock_match):
    mock_match.groups = ('\\101', '101')
    result = escape(mock_match)
    assert result == 'A'  # ASCII for 65

def test_escape_octal_escape_invalid_value(mock_match):
    mock_match.groups = ('\\8', '8')
    with pytest.raises(ValueError, match="invalid octal string escape"):
        escape(mock_match)
