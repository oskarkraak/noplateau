# file: blib2to3/blib2to3.pgen2.literals.py:47-55
# asked: {"lines": [48, 49, 50, 51, 52, 53, 54, 55], "branches": [[50, 51], [50, 52]]}
# gained: {"lines": [48, 49, 50, 51, 52, 53, 54, 55], "branches": [[50, 51], [50, 52]]}

import pytest
import re
from blib2to3.pgen2.literals import evalString

def escape(match):
    return match.group(0)  # Dummy escape function for testing

def test_evalString_single_quote():
    result = evalString("'Hello, World!'")
    assert result == "Hello, World!"

def test_evalString_double_quote():
    result = evalString('"Hello, World!"')
    assert result == "Hello, World!"

def test_evalString_triple_single_quote():
    result = evalString("'''Hello, World!'''")
    assert result == "Hello, World!"

def test_evalString_triple_double_quote():
    result = evalString('"""Hello, World!"""')
    assert result == "Hello, World!"

def test_evalString_with_escape_sequences():
    result = evalString("'Hello, \\'World\\'!'")
    assert result == "Hello, 'World'!"

def test_evalString_with_triple_quotes_and_escape_sequences():
    result = evalString("'''Hello, \\'World\\'!'''")
    assert result == "Hello, 'World'!"
