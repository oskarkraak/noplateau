import pytest
import re
from blib2to3.pgen2.literals import escape

simple_escapes = {
    'n': '\n',
    't': '\t',
    'r': '\r',
    'b': '\b',
    'f': '\f',
    '\\': '\\',
    '\'': '\'',
    '\"': '\"',
}

@pytest.fixture
def mock_match():
    class MockMatch:
        def group(self, *args):
            return self.groups

    return MockMatch()

def test_iter2_1_escape_simple_escape(mock_match):
    for escape_char, expected in simple_escapes.items():
        mock_match.groups = (f'\\{escape_char}', escape_char)
        result = escape(mock_match)
        assert result == expected

def test_iter2_1_escape_hex_escape_valid(mock_match):
    mock_match.groups = ('\\x41', 'x41')
    result = escape(mock_match)
    assert result == 'A'  # ASCII for 65

def test_iter2_1_escape_hex_escape_invalid_length(mock_match):
    mock_match.groups = ('\\x4', 'x4')
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(mock_match)

def test_iter2_1_escape_hex_escape_invalid_value(mock_match):
    mock_match.groups = ('\\xG1', 'xG1')
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(mock_match)

def test_iter2_1_escape_octal_escape_valid(mock_match):
    mock_match.groups = ('\\101', '101')
    result = escape(mock_match)
    assert result == 'A'  # ASCII for 65

def test_iter2_1_escape_octal_escape_invalid_value(mock_match):
    mock_match.groups = ('\\8', '8')
    with pytest.raises(ValueError, match="invalid octal string escape"):
        escape(mock_match)

