import pytest
from blib2to3.pgen2.literals import evalString, escape

# Tests for evalString function
def test_evalString_empty_string():
    result = evalString("''")
    assert result == ""

def test_evalString_single_quote():
    result = evalString("'Hello, World!'")
    assert result == "Hello, World!"

def test_evalString_double_quote():
    result = evalString('"Hello, World!"')
    assert result == "Hello, World!"

def test_evalString_triple_single_quote():
    result = evalString("'''Hello, World!'''")
    assert result == "Hello, World!"

def test_evalString_triple_double_quote():
    result = evalString('"""Hello, World!"""')
    assert result == "Hello, World!"

def test_evalString_with_escape_sequences():
    result = evalString("'Hello, \\'World\\'!'")
    assert result == "Hello, 'World'!"

def test_evalString_with_triple_quotes_and_escape_sequences():
    result = evalString("'''Hello, \\'World\\'!'''")
    assert result == "Hello, 'World'!"

def test_evalString_mixed_quotes():
    result = evalString('"Hello, \'World\'!"')
    assert result == "Hello, 'World'!"

def test_evalString_escaped_quotes():
    result = evalString("'Hello, \\'World\\'!'")
    assert result == "Hello, 'World'!"

def test_evalString_triple_quotes_with_newline():
    result = evalString('"""Hello,\nWorld!"""')
    assert result == "Hello,\nWorld!"

def test_evalString_triple_single_quote_with_escape():
    result = evalString("'''Hello, \\'World\\'!'''")
    assert result == "Hello, 'World'!"

def test_evalString_empty_triple_quotes():
    result = evalString("''' '''")
    assert result == " "

def test_evalString_triple_quotes_with_only_newline():
    result = evalString('"""\n"""')
    assert result == "\n"

# Tests for escape function
simple_escapes = {
    'n': '\n',
    't': '\t',
    'r': '\r',
    'b': '\b',
    'f': '\f',
    '\\': '\\',
    '\'': '\'',
    '\"': '\"',
}

@pytest.fixture
def mock_match():
    class MockMatch:
        def group(self, *args):
            return self.groups

    return MockMatch()

def test_escape_simple_escapes(mock_match):
    for escape_char, expected in simple_escapes.items():
        mock_match.groups = (f'\\{escape_char}', escape_char)
        result = escape(mock_match)
        assert result == expected

def test_escape_hex_escape_valid(mock_match):
    mock_match.groups = ('\\x41', 'x41')
    result = escape(mock_match)
    assert result == 'A'  # ASCII for 65

def test_escape_hex_escape_invalid_length(mock_match):
    mock_match.groups = ('\\x4', 'x4')
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(mock_match)

def test_escape_hex_escape_invalid_value(mock_match):
    mock_match.groups = ('\\xG1', 'xG1')
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(mock_match)

def test_escape_octal_escape_valid(mock_match):
    mock_match.groups = ('\\101', '101')
    result = escape(mock_match)
    assert result == 'A'  # ASCII for 65

def test_escape_octal_escape_invalid_value(mock_match):
    mock_match.groups = ('\\8', '8')
    with pytest.raises(ValueError, match="invalid octal string escape"):
        escape(mock_match)

