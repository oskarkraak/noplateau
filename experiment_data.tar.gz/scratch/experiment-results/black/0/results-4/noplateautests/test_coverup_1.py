# file: blib2to3/blib2to3.pgen2.literals.py:58-64
# asked: {"lines": [58, 59, 60, 61, 62, 63, 64], "branches": [[59, 0], [59, 60], [63, 59], [63, 64]]}
# gained: {"lines": [58], "branches": []}

import pytest
from blib2to3.pgen2.literals import evalString

def test_eval_string_single_character():
    # Test for single character strings
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, f"Failed for character: {c} (ASCII: {i})"

def test_eval_string_double_quotes():
    # Test for double quoted strings
    test_strings = ['"a"', '"\\n"', '"\\t"', '"\\\\"']
    for s in test_strings:
        e = evalString(s)
        assert e == eval(s), f"Failed for string: {s}"

def test_eval_string_triple_quotes():
    # Test for triple quoted strings
    test_strings = ['"""abc"""', '"""\\n"""', '"""\\t"""', '"""\\\\"""']
    for s in test_strings:
        e = evalString(s)
        assert e == eval(s), f"Failed for string: {s}"

def test_eval_string_with_escapes():
    # Test for strings with various escape sequences
    test_strings = [
        "'\\n'", "'\\t'", "'\\\\'", "'\\x41'", "'\\077'", "'\\x41\\n'"
    ]
    for s in test_strings:
        e = evalString(s)
        assert e == eval(s), f"Failed for string: {s}"
