# file: blib2to3/blib2to3.pgen2.literals.py:25-44
# asked: {"lines": [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44], "branches": [[29, 30], [29, 31], [31, 32], [31, 40], [33, 34], [33, 35]]}
# gained: {"lines": [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44], "branches": [[29, 30], [29, 31], [31, 32], [31, 40], [33, 34], [33, 35]]}

import pytest
import re
from blib2to3.pgen2.literals import escape

simple_escapes = {
    'n': '\n',
    't': '\t',
    # Add other simple escapes as needed
}

@pytest.fixture
def mock_match():
    class MockMatch:
        def __init__(self, group_values):
            self.group_values = group_values

        def group(self, *args):
            return self.group_values

    return MockMatch

def test_escape_simple_escape(mock_match):
    m = mock_match(('\\n', 'n'))
    result = escape(m)
    assert result == simple_escapes['n']

def test_escape_hex_escape_valid(mock_match):
    m = mock_match(('\\x41', 'x41'))
    result = escape(m)
    assert result == 'A'  # ASCII for 65

def test_escape_hex_escape_invalid_length(mock_match):
    m = mock_match(('\\x4', 'x4'))
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(m)

def test_escape_hex_escape_invalid_value(mock_match):
    m = mock_match(('\\xG1', 'xG1'))
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(m)

def test_escape_octal_escape_valid(mock_match):
    m = mock_match(('\\101', '101'))
    result = escape(m)
    assert result == 'A'  # ASCII for 65

def test_escape_octal_escape_invalid_value(mock_match):
    m = mock_match(('\\8', '8'))
    with pytest.raises(ValueError, match="invalid octal string escape"):
        escape(m)
