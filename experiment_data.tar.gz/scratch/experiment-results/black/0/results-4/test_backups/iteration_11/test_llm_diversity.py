import pytest
from blib2to3.pgen2.literals import evalString, escape

# Tests for evalString function
def test_eval_string_empty():
    s = "''"
    e = evalString(s)
    assert e == '', f"Failed for empty string"

def test_eval_string_single_character():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, f"Failed for character: {c} (ASCII: {i})"

def test_eval_string_triple_quotes():
    test_strings = ['"""abc"""', '"""\\n"""', '"""\\t"""', '"""\\\\"""', '"""abc\\n"""']
    for s in test_strings:
        e = evalString(s)
        assert e == eval(s), f"Failed for string: {s}"

def test_eval_string_single_quote():
    test_strings = ["'abc'", "'\\n'", "'\\t'", "'\\\\'"]
    for s in test_strings:
        e = evalString(s)
        assert e == eval(s), f"Failed for string: {s}"

def test_eval_string_double_quotes():
    test_strings = ['"abc"', '"\\n"', '"\\t"', '"\\\\"']
    for s in test_strings:
        e = evalString(s)
        assert e == eval(s), f"Failed for string: {s}"

def test_eval_string_with_escapes():
    test_strings = [
        "'\\n'", "'\\t'", "'\\\\'", "'\\x41'", "'\\077'", "'\\x41\\n'",
        '"\\n"', '"\\t"', '"\\\\"', '"\\x41"', '"\\077"', '"\\x41\\n"'
    ]
    for s in test_strings:
        e = evalString(s)
        assert e == eval(s), f"Failed for string: {s}"

# Tests for escape function
simple_escapes = {
    'n': '\n',
    't': '\t',
    'r': '\r',
    'b': '\b',
    'f': '\f',
    '\\': '\\',
}

@pytest.fixture
def mock_match():
    class MockMatch:
        def __init__(self, group_values):
            self.group_values = group_values

        def group(self, *args):
            return self.group_values

    return MockMatch

def test_escape_simple_escape(mock_match):
    for key, value in simple_escapes.items():
        m = mock_match((f'\\{key}', key))
        result = escape(m)
        assert result == value, f"Failed for escape: \\{key}"

def test_escape_hex_escape_valid(mock_match):
    m = mock_match(('\\x41', 'x41'))
    result = escape(m)
    assert result == 'A'  # ASCII for 65

def test_escape_hex_escape_invalid_length(mock_match):
    m = mock_match(('\\x4', 'x4'))
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(m)

def test_escape_hex_escape_invalid_value(mock_match):
    m = mock_match(('\\xG1', 'xG1'))
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(m)

def test_escape_octal_escape_valid(mock_match):
    m = mock_match(('\\101', '101'))
    result = escape(m)
    assert result == 'A'  # ASCII for 65

def test_escape_octal_escape_invalid_value(mock_match):
    m = mock_match(('\\8', '8'))
    with pytest.raises(ValueError, match="invalid octal string escape"):
        escape(m)

