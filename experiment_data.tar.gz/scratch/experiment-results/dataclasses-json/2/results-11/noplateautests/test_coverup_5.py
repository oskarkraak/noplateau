# file: dataclasses_json.core.py:283-292
# asked: {"lines": [283, 290, 291, 292], "branches": []}
# gained: {"lines": [283, 290, 291, 292], "branches": []}

import pytest
from typing import Any
from dataclasses_json.core import _decode_dict_keys

def test_decode_dict_keys_with_none_type(monkeypatch):
    # Mock _decode_items to control its output
    def mock_decode_items(key_type, xs, infer_missing):
        return ['key1', 'key2', 'key3']
    
    monkeypatch.setattr('dataclasses_json.core._decode_items', mock_decode_items)
    
    result = list(_decode_dict_keys(None, ['key1', 'key2', 'key3'], False))
    assert result == ['key1', 'key2', 'key3']

def test_decode_dict_keys_with_any_type(monkeypatch):
    # Mock _decode_items to control its output
    def mock_decode_items(key_type, xs, infer_missing):
        return ['key1', 'key2', 'key3']
    
    monkeypatch.setattr('dataclasses_json.core._decode_items', mock_decode_items)
    
    result = list(_decode_dict_keys(Any, ['key1', 'key2', 'key3'], False))
    assert result == ['key1', 'key2', 'key3']

def test_decode_dict_keys_with_specific_type(monkeypatch):
    # Mock _decode_items to control its output
    def mock_decode_items(key_type, xs, infer_missing):
        return ['key1', 'key2', 'key3']
    
    monkeypatch.setattr('dataclasses_json.core._decode_items', mock_decode_items)
    
    result = list(_decode_dict_keys(str, ['key1', 'key2', 'key3'], False))
    assert result == ['key1', 'key2', 'key3']
