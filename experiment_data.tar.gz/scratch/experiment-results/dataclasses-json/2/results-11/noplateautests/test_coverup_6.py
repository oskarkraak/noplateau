# file: dataclasses_json.core.py:130-208
# asked: {"lines": [130, 131, 132, 133, 134, 135, 136, 137, 138, 140, 141, 142, 143, 144, 145, 146, 149, 151, 152, 153, 156, 157, 159, 160, 161, 162, 163, 164, 165, 166, 169, 171, 172, 173, 175, 176, 177, 179, 181, 182, 184, 185, 187, 188, 189, 194, 195, 197, 198, 199, 200, 201, 202, 203, 205, 206, 208], "branches": [[131, 132], [131, 133], [140, 141], [140, 149], [141, 142], [141, 143], [143, 144], [143, 145], [145, 140], [145, 146], [153, 156], [153, 208], [156, 157], [156, 159], [161, 162], [161, 175], [164, 165], [164, 171], [175, 176], [176, 177], [176, 179], [181, 184], [181, 189], [184, 185], [184, 187], [189, 194], [189, 200], [194, 195], [194, 197], [200, 201], [200, 205]]}
# gained: {"lines": [130, 131, 133, 134, 135, 136, 137, 138, 140, 141, 142, 143, 144, 145, 146, 149, 151, 152, 153, 156, 159, 160, 161, 162, 163, 164, 165, 166, 169, 171, 172, 173, 175, 176, 177, 181, 182, 189, 200, 201, 202, 203, 205, 206, 208], "branches": [[131, 133], [140, 141], [140, 149], [141, 142], [141, 143], [143, 144], [143, 145], [145, 146], [153, 156], [153, 208], [156, 159], [161, 162], [161, 175], [164, 165], [164, 171], [175, 176], [176, 177], [181, 189], [189, 200], [200, 201], [200, 205]]}

import pytest
import warnings
from dataclasses import dataclass, field
from typing import Optional
from dataclasses_json.core import _decode_dataclass

@dataclass
class TestDataClass:
    name: str
    age: Optional[int] = field(default=None)
    address: Optional[str] = field(default_factory=lambda: "Unknown")

def test_decode_dataclass_with_all_fields():
    kvs = {"name": "John Doe", "age": 30}
    result = _decode_dataclass(TestDataClass, kvs, infer_missing=True)
    assert result.name == "John Doe"
    assert result.age == 30
    assert result.address == "Unknown"

def test_decode_dataclass_with_missing_optional_field():
    kvs = {"name": "Jane Doe"}
    result = _decode_dataclass(TestDataClass, kvs, infer_missing=True)
    assert result.name == "Jane Doe"
    assert result.age is None
    assert result.address == "Unknown"

def test_decode_dataclass_with_missing_required_field():
    kvs = {"age": 25}
    with pytest.warns(RuntimeWarning, match="value of non-optional type name detected when decoding TestDataClass"):
        result = _decode_dataclass(TestDataClass, kvs, infer_missing=True)
    assert result.age == 25
    assert result.name is None
    assert result.address == "Unknown"

def test_decode_dataclass_with_infer_missing():
    kvs = {"name": "Alice"}
    result = _decode_dataclass(TestDataClass, kvs, infer_missing=True)
    assert result.name == "Alice"
    assert result.age is None
    assert result.address == "Unknown"

def test_decode_dataclass_with_default_factory():
    kvs = {"name": "Bob", "age": None}
    result = _decode_dataclass(TestDataClass, kvs, infer_missing=True)
    assert result.name == "Bob"
    assert result.age is None
    assert result.address == "Unknown"

def test_decode_dataclass_with_warning_for_non_optional():
    kvs = {"name": None}
    with pytest.warns(RuntimeWarning, match="`NoneType` object value of non-optional type name detected when decoding TestDataClass"):
        result = _decode_dataclass(TestDataClass, kvs, infer_missing=False)
    assert result.name is None
    assert result.age is None
    assert result.address == "Unknown"
