# file: dataclasses_json.core.py:130-208
# asked: {"lines": [132, 157, 179, 184, 185, 187, 188, 194, 195, 197, 198, 199], "branches": [[131, 132], [145, 140], [156, 157], [176, 179], [181, 184], [184, 185], [184, 187], [189, 194], [194, 195], [194, 197]]}
# gained: {"lines": [132, 194, 195, 199], "branches": [[131, 132], [189, 194], [194, 195]]}

import pytest
from dataclasses import dataclass
from dataclasses_json.core import _decode_dataclass

@dataclass
class TestDataClass:
    a: int
    b: str = "default"
    c: float = 0.0

def test_decode_dataclass_with_instance():
    instance = TestDataClass(a=1, b="test")
    result = _decode_dataclass(TestDataClass, instance, infer_missing=False)
    assert result == instance

def test_decode_dataclass_with_missing_fields_infer_missing():
    result = _decode_dataclass(TestDataClass, None, infer_missing=True)
    assert result.a is None  # a should be None when infer_missing is True
    assert result.b == "default"  # default value for b
    assert result.c == 0.0  # default value for c

def test_decode_dataclass_with_none_value():
    with pytest.warns(RuntimeWarning, match="value of non-optional type a detected when decoding TestDataClass"):
        result = _decode_dataclass(TestDataClass, {'a': None}, infer_missing=False)
    assert result.a is None

def test_decode_dataclass_with_optional_field():
    result = _decode_dataclass(TestDataClass, {'a': 1, 'b': None}, infer_missing=True)
    assert result.a == 1
    assert result.b is None  # b is optional and can be None

def test_decode_dataclass_with_custom_decoder():
    @dataclass
    class CustomDataClass:
        a: int
        b: str

        @classmethod
        def custom_decoder(cls, value):
            return cls(a=value['a'], b=value['b'].upper())

    # Use the custom decoder explicitly
    result = CustomDataClass.custom_decoder({'a': 1, 'b': 'test'})
    assert result.b == 'TEST'  # Check if custom decoder works

def test_decode_dataclass_with_nested_dataclass():
    @dataclass
    class NestedDataClass:
        d: int

    @dataclass
    class OuterDataClass:
        c: NestedDataClass

    nested_instance = NestedDataClass(d=5)
    result = _decode_dataclass(OuterDataClass, {'c': nested_instance}, infer_missing=False)
    assert result.c.d == 5

def test_decode_dataclass_with_unsupported_type():
    @dataclass
    class UnsupportedTypeDataClass:
        a: int

    result = _decode_dataclass(UnsupportedTypeDataClass, {'a': 'string'}, infer_missing=False)
    assert result.a == 'string'  # Check if it accepts unsupported types
