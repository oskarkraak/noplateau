# file: dataclasses_json.core.py:118-127
# asked: {"lines": [118, 120, 121, 122, 123, 124, 125, 126, 127], "branches": [[121, 122], [121, 127], [123, 121], [123, 124], [125, 121], [125, 126]]}
# gained: {"lines": [118, 120, 121, 122, 123, 124, 125, 126, 127], "branches": [[121, 122], [121, 127], [123, 121], [123, 124], [125, 121], [125, 126]]}

import pytest
from dataclasses_json.core import _decode_letter_case_overrides

class FieldOverride:
    def __init__(self, letter_case):
        self.letter_case = letter_case

def test_decode_letter_case_overrides_with_no_overrides():
    field_names = ['name', 'age']
    overrides = {}
    result = _decode_letter_case_overrides(field_names, overrides)
    assert result == {}

def test_decode_letter_case_overrides_with_none_letter_case():
    field_names = ['name', 'age']
    overrides = {
        'name': FieldOverride(letter_case=None),
        'age': FieldOverride(letter_case=None)
    }
    result = _decode_letter_case_overrides(field_names, overrides)
    assert result == {}

def test_decode_letter_case_overrides_with_valid_letter_case():
    field_names = ['name', 'age']
    overrides = {
        'name': FieldOverride(letter_case=str.upper),
        'age': FieldOverride(letter_case=str.lower)
    }
    result = _decode_letter_case_overrides(field_names, overrides)
    assert result == {'NAME': 'name', 'age': 'age'}

def test_decode_letter_case_overrides_with_partial_overrides():
    field_names = ['name', 'age', 'email']
    overrides = {
        'name': FieldOverride(letter_case=str.upper),
        'age': FieldOverride(letter_case=None),
        'email': FieldOverride(letter_case=str.lower)
    }
    result = _decode_letter_case_overrides(field_names, overrides)
    assert result == {'NAME': 'name', 'email': 'email'}
