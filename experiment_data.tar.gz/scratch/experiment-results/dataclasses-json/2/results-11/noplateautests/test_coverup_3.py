# file: dataclasses_json.core.py:315-338
# asked: {"lines": [315, 320, 321, 322, 323, 324, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 338], "branches": [[320, 321], [320, 330], [322, 323], [322, 326], [330, 331], [330, 334], [334, 336], [334, 338]]}
# gained: {"lines": [315, 320, 321, 322, 323, 324, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 338], "branches": [[320, 321], [320, 330], [322, 323], [322, 326], [330, 331], [330, 334], [334, 336], [334, 338]]}

import pytest
from dataclasses import dataclass
from typing import List, Dict, Any
from dataclasses_json.core import _asdict

@dataclass
class TestDataClass:
    name: str
    value: int
    nested: 'TestDataClass' = None

@pytest.fixture
def mock_data_class():
    return TestDataClass(name="Test", value=42, nested=TestDataClass(name="Nested", value=24))

def test_asdict_with_dataclass(mock_data_class):
    result = _asdict(mock_data_class)
    assert result == {
        'name': 'Test',
        'value': 42,
        'nested': {
            'name': 'Nested',
            'value': 24,
            'nested': None
        }
    }

def test_asdict_with_mapping():
    test_mapping: Dict[str, Any] = {'key1': 1, 'key2': {'subkey': 2}}
    result = _asdict(test_mapping)
    assert result == {
        'key1': 1,
        'key2': {'subkey': 2}
    }

def test_asdict_with_collection():
    test_collection: List[Any] = [1, 2, {'key': 3}]
    result = _asdict(test_collection)
    assert result == [1, 2, {'key': 3}]

def test_asdict_with_primitive():
    test_primitive = "string"
    result = _asdict(test_primitive)
    assert result == "string"

def test_asdict_with_bytes():
    test_bytes = b'bytes'
    result = _asdict(test_bytes)
    assert result == b'bytes'
