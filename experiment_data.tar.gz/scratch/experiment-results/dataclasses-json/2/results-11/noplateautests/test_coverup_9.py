# file: dataclasses_json.core.py:295-312
# asked: {"lines": [305, 306, 307, 308, 309, 311, 312], "branches": [[305, 306], [305, 308], [308, 309], [308, 311]]}
# gained: {"lines": [305, 306, 307, 308, 311, 312], "branches": [[305, 306], [305, 308], [308, 311]]}

import pytest
from dataclasses import dataclass
from dataclasses_json.core import _decode_items

@dataclass
class TestDataClass:
    id: int
    name: str

def test_decode_items_with_dataclass_type_arg():
    type_arg = TestDataClass
    xs = [{'id': 1, 'name': 'Test'}]
    infer_missing = False

    result = list(_decode_items(type_arg, xs, infer_missing))

    assert len(result) == 1
    assert result[0].id == 1
    assert result[0].name == 'Test'

def test_decode_items_with_dataclass_xs():
    type_arg = int
    xs = [TestDataClass(id=1, name='Test')]
    infer_missing = False

    result = list(_decode_items(type_arg, xs, infer_missing))

    assert result == xs

def test_decode_items_with_unsupported_type():
    type_arg = str
    xs = [1, 2, 3]
    infer_missing = False

    result = list(_decode_items(type_arg, xs, infer_missing))

    assert result == xs
