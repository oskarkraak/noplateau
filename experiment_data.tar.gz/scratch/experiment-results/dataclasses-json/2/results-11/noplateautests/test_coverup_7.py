# file: dataclasses_json.core.py:90-93
# asked: {"lines": [91, 92, 93], "branches": [[91, 92], [91, 93]]}
# gained: {"lines": [91, 92, 93], "branches": [[91, 92], [91, 93]]}

import pytest
from dataclasses_json.core import _encode_json_type
import json

class CustomType:
    pass

@pytest.mark.parametrize("value, expected", [
    ({"key": "value"}, {"key": "value"}),  # Testing with a dict
    ([1, 2, 3], [1, 2, 3]),                # Testing with a list
    ("string", "string"),                  # Testing with a string
    (42, 42),                              # Testing with an int
    (3.14, 3.14),                          # Testing with a float
    (True, True),                          # Testing with a bool
    (None, None),                          # Testing with None
])
def test_encode_json_type_with_valid_json(value, expected):
    result = _encode_json_type(value)
    assert result == expected

def test_encode_json_type_with_invalid_type(monkeypatch):
    def mock_default(self, o):
        raise TypeError(f'Object of type {o.__class__.__name__} is not JSON serializable')

    monkeypatch.setattr(json.JSONEncoder, 'default', mock_default)
    
    value = CustomType()
    with pytest.raises(TypeError, match="Object of type CustomType is not JSON serializable"):
        _encode_json_type(value)
