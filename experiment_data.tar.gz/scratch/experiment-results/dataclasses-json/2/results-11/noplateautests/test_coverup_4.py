# file: dataclasses_json.core.py:32-50
# asked: {"lines": [32, 33, 35, 36, 37, 39, 40, 41, 42, 43, 44, 45, 46, 47, 49, 50], "branches": [[35, 36], [35, 40], [36, 37], [36, 39], [40, 41], [40, 42], [42, 43], [42, 44], [44, 45], [44, 46], [46, 47], [46, 49]]}
# gained: {"lines": [32, 33, 35, 36, 37, 39, 40, 41, 42, 43, 44, 45, 46, 47, 49, 50], "branches": [[35, 36], [35, 40], [36, 37], [36, 39], [40, 41], [40, 42], [42, 43], [42, 44], [44, 45], [44, 46], [46, 47], [46, 49]]}

import json
import pytest
from datetime import datetime
from decimal import Decimal
from enum import Enum
from uuid import UUID
from dataclasses_json.utils import _isinstance_safe
from dataclasses_json.core import _ExtendedEncoder

class TestExtendedEncoder:
    def test_encode_collection_mapping(self):
        data = {'key': 'value'}
        encoder = _ExtendedEncoder()
        result = encoder.default(data)
        assert result == data  # Expecting a dict to be returned as is

    def test_encode_collection_sequence(self):
        data = [1, 2, 3]
        encoder = _ExtendedEncoder()
        result = encoder.default(data)
        assert result == data  # Expecting a list to be returned as is

    def test_encode_datetime(self):
        data = datetime(2023, 1, 1)
        encoder = _ExtendedEncoder()
        result = encoder.default(data)
        assert result == data.timestamp()  # Expecting the timestamp of the datetime

    def test_encode_uuid(self):
        data = UUID('12345678-1234-5678-1234-567812345678')
        encoder = _ExtendedEncoder()
        result = encoder.default(data)
        assert result == str(data)  # Expecting the UUID to be returned as a string

    def test_encode_enum(self):
        class SampleEnum(Enum):
            VALUE1 = 1
            VALUE2 = 2

        data = SampleEnum.VALUE1
        encoder = _ExtendedEncoder()
        result = encoder.default(data)
        assert result == data.value  # Expecting the enum value to be returned

    def test_encode_decimal(self):
        data = Decimal('10.5')
        encoder = _ExtendedEncoder()
        result = encoder.default(data)
        assert result == str(data)  # Expecting the Decimal to be returned as a string

    def test_encode_unknown_type(self):
        class CustomClass:
            pass

        data = CustomClass()
        encoder = _ExtendedEncoder()
        with pytest.raises(TypeError):
            encoder.default(data)  # Expecting a TypeError for non-serializable type
