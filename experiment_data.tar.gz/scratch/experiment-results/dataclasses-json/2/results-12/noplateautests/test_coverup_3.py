# file: dataclasses_json.cfg.py:44-97
# asked: {"lines": [44, 47, 48, 49, 50, 51, 52, 53, 55, 56, 58, 60, 61, 63, 64, 66, 67, 69, 70, 71, 72, 73, 75, 76, 77, 79, 80, 82, 84, 85, 86, 87, 88, 89, 90, 92, 94, 95, 97], "branches": [[55, 56], [55, 58], [60, 61], [60, 63], [63, 64], [63, 66], [66, 67], [66, 69], [69, 70], [69, 79], [70, 72], [70, 75], [79, 80], [79, 82], [82, 84], [82, 94], [84, 85], [84, 92], [85, 86], [85, 90], [94, 95], [94, 97]]}
# gained: {"lines": [44, 47, 48, 49, 50, 51, 52, 53, 55, 58, 60, 61, 63, 64, 66, 67, 69, 70, 71, 72, 73, 77, 79, 80, 82, 84, 85, 86, 87, 88, 89, 92, 94, 95, 97], "branches": [[55, 58], [60, 61], [60, 63], [63, 64], [63, 66], [66, 67], [66, 69], [69, 70], [69, 79], [70, 72], [79, 80], [79, 82], [82, 84], [82, 94], [84, 85], [84, 92], [85, 86], [94, 95], [94, 97]]}

import pytest
from marshmallow.fields import Field as MarshmallowField
from dataclasses_json.cfg import config
from dataclasses_json.undefined import Undefined, UndefinedParameterError

def test_config_with_encoder():
    metadata = {}
    encoder = lambda x: x
    result = config(metadata, encoder=encoder)
    assert result['dataclasses_json']['encoder'] == encoder

def test_config_with_decoder():
    metadata = {}
    decoder = lambda x: x
    result = config(metadata, decoder=decoder)
    assert result['dataclasses_json']['decoder'] == decoder

def test_config_with_mm_field():
    metadata = {}
    mm_field = MarshmallowField()
    result = config(metadata, mm_field=mm_field)
    assert result['dataclasses_json']['mm_field'] == mm_field

def test_config_with_letter_case():
    metadata = {}
    field_name = "test_field"
    letter_case = lambda x: x.upper()
    result = config(metadata, field_name=field_name, letter_case=letter_case)
    assert result['dataclasses_json']['letter_case'](field_name) == "TEST_FIELD"

def test_config_with_undefined_string():
    metadata = {}
    undefined = "INVALID_ACTION"
    with pytest.raises(UndefinedParameterError) as excinfo:
        config(metadata, undefined=undefined)
    assert "must be one of" in str(excinfo.value)

def test_config_with_undefined_enum():
    metadata = {}
    undefined = Undefined.RAISE
    result = config(metadata, undefined=undefined)
    assert result['dataclasses_json']['undefined'] == undefined

def test_config_with_exclude():
    metadata = {}
    exclude = lambda field_name, value: field_name == "exclude_field"
    result = config(metadata, exclude=exclude)
    assert result['dataclasses_json']['exclude'] == exclude
