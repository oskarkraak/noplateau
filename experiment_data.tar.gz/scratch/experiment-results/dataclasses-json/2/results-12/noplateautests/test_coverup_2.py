# file: dataclasses_json.cfg.py:21-26
# asked: {"lines": [21, 23, 24, 25, 26], "branches": []}
# gained: {"lines": [21, 23, 24, 25, 26], "branches": []}

import pytest
from dataclasses_json.cfg import _GlobalConfig

@pytest.fixture
def global_config():
    config = _GlobalConfig()
    yield config
    # No cleanup necessary as there are no external resources to release

def test_initial_encoders(global_config):
    assert isinstance(global_config.encoders, dict)
    assert len(global_config.encoders) == 0

def test_initial_decoders(global_config):
    assert isinstance(global_config.decoders, dict)
    assert len(global_config.decoders) == 0

def test_initial_mm_fields(global_config):
    assert isinstance(global_config.mm_fields, dict)
    assert len(global_config.mm_fields) == 0
