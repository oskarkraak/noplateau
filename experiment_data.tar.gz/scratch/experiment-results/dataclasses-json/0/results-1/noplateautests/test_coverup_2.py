# file: dataclasses_json.core.py:96-115
# asked: {"lines": [96, 97, 98, 99, 100, 103, 104, 105, 106, 107, 109, 110, 112, 113, 114, 115], "branches": [[98, 99], [98, 115], [99, 100], [99, 112], [103, 104], [103, 105], [112, 113], [112, 114]]}
# gained: {"lines": [96, 97, 98, 99, 100, 103, 104, 105, 106, 107, 109, 110, 112, 113, 114, 115], "branches": [[98, 99], [98, 115], [99, 100], [103, 104], [103, 105], [112, 113], [112, 114]]}

import pytest
from dataclasses_json.core import _encode_overrides

class MockOverride:
    def __init__(self, exclude=None, letter_case=None, encoder=None):
        self.exclude = exclude
        self.letter_case = letter_case
        self.encoder = encoder

def test_encode_overrides_with_exclude(monkeypatch):
    kvs = {'key1': 'value1', 'key2': 'value2'}
    overrides = {
        'key1': MockOverride(exclude=lambda x: x == 'value1'),
        'key2': MockOverride()
    }
    
    result = _encode_overrides(kvs, overrides)
    
    assert 'key1' not in result
    assert result['key2'] == 'value2'

def test_encode_overrides_with_letter_case(monkeypatch):
    kvs = {'key1': 'value1'}
    overrides = {
        'key1': MockOverride(letter_case=lambda x: x.upper())
    }
    
    result = _encode_overrides(kvs, overrides)
    
    assert 'KEY1' in result
    assert result['KEY1'] == 'value1'

def test_encode_overrides_with_encoder(monkeypatch):
    kvs = {'key1': 'value1'}
    overrides = {
        'key1': MockOverride(encoder=lambda x: x + '_encoded')
    }
    
    result = _encode_overrides(kvs, overrides)
    
    assert 'key1' in result
    assert result['key1'] == 'value1_encoded'

def test_encode_overrides_with_json_encoding(monkeypatch):
    kvs = {'key1': {'nested_key': 'nested_value'}}
    overrides = {
        'key1': MockOverride()
    }
    
    # Mocking _encode_json_type function
    def mock_encode_json_type(v):
        return {'json_key': v['nested_key']}
    
    monkeypatch.setattr('dataclasses_json.core._encode_json_type', mock_encode_json_type)
    
    result = _encode_overrides(kvs, overrides, encode_json=True)
    
    assert 'key1' in result
    assert result['key1'] == {'json_key': 'nested_value'}
