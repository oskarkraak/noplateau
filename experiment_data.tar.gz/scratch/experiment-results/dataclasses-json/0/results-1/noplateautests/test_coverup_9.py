# file: dataclasses_json.core.py:295-312
# asked: {"lines": [309], "branches": [[308, 309]]}
# gained: {"lines": [309], "branches": [[308, 309]]}

import pytest
from dataclasses import dataclass
from typing import List, Union, Generic, TypeVar
from dataclasses_json.core import _decode_items

T = TypeVar('T')

@dataclass
class SampleDataClass:
    value: int

class SampleGeneric(Generic[T]):
    items: List[T]

def test_decode_items_with_supported_generic():
    type_arg = SampleGeneric[SampleDataClass]
    xs = [SampleDataClass(1), SampleDataClass(2)]
    infer_missing = False

    result = list(_decode_items(type_arg, xs, infer_missing))
    
    assert len(result) == 2
    assert all(isinstance(item, SampleDataClass) for item in result)
    assert result[0].value == 1
    assert result[1].value == 2

def test_decode_items_with_union_type():
    type_arg = Union[SampleDataClass, int]
    xs = [SampleDataClass(1), 2]
    infer_missing = False

    result = list(_decode_items(type_arg, xs, infer_missing))
    
    assert len(result) == 2
    assert isinstance(result[0], SampleDataClass)
    assert result[0].value == 1
    assert result[1] == 2

def test_decode_items_with_non_generic():
    type_arg = str
    xs = ["test", "example"]
    infer_missing = False

    result = list(_decode_items(type_arg, xs, infer_missing))
    
    assert len(result) == 2
    assert result == xs
