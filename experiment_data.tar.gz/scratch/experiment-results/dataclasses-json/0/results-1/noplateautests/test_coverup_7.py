# file: dataclasses_json.core.py:234-238
# asked: {"lines": [235, 236, 237, 238], "branches": []}
# gained: {"lines": [235, 236, 237, 238], "branches": []}

import pytest
from enum import Enum
from dataclasses_json.utils import _is_collection, _is_optional, _issubclass_safe
from dataclasses_json.core import _is_supported_generic

class TestEnum(Enum):
    VALUE1 = 1
    VALUE2 = 2

def test_is_supported_generic_with_collection():
    class CustomCollection(list):
        pass

    assert _is_supported_generic(CustomCollection) is True

def test_is_supported_generic_with_optional():
    from typing import Optional

    assert _is_supported_generic(Optional[int]) is True
    assert _is_supported_generic(Optional[str]) is True

def test_is_supported_generic_with_union():
    from typing import Union

    assert _is_supported_generic(Union[int, str]) is True

def test_is_supported_generic_with_enum():
    assert _is_supported_generic(TestEnum) is True

def test_is_supported_generic_with_non_collection():
    class NonCollection:
        pass

    assert _is_supported_generic(NonCollection) is False

def test_is_supported_generic_with_str():
    assert _is_supported_generic(str) is False
