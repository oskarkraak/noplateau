# file: dataclasses_json.cfg.py:44-97
# asked: {"lines": [56, 75, 76, 90], "branches": [[55, 56], [70, 75], [85, 90]]}
# gained: {"lines": [56, 75, 76, 90], "branches": [[55, 56], [70, 75], [85, 90]]}

import pytest
from dataclasses_json.cfg import config
from dataclasses_json.undefined import Undefined, UndefinedParameterError

def test_config_with_default_metadata():
    result = config()
    assert result == {'dataclasses_json': {}}

def test_config_with_encoder():
    result = config(encoder=lambda x: x)
    assert result['dataclasses_json']['encoder'] is not None

def test_config_with_decoder():
    result = config(decoder=lambda x: x)
    assert result['dataclasses_json']['decoder'] is not None

def test_config_with_mm_field():
    mock_field = object()  # Replace with an actual MarshmallowField if needed
    result = config(mm_field=mock_field)
    assert result['dataclasses_json']['mm_field'] is mock_field

def test_config_with_letter_case():
    result = config(field_name='test_field', letter_case=lambda x: x.upper())
    assert result['dataclasses_json']['letter_case'] is not None

def test_config_letter_case_override():
    result = config(field_name='test_field')
    assert result['dataclasses_json']['letter_case']('test_field') == 'test_field'

def test_config_with_valid_undefined_string():
    result = config(undefined='INCLUDE')
    assert result['dataclasses_json']['undefined'] is Undefined.INCLUDE

def test_config_with_invalid_undefined_string():
    with pytest.raises(UndefinedParameterError) as excinfo:
        config(undefined='INVALID_ACTION')
    assert "Invalid undefined parameter action" in str(excinfo.value)

def test_config_with_exclude():
    result = config(exclude=lambda x, y: False)
    assert result['dataclasses_json']['exclude'] is not None
