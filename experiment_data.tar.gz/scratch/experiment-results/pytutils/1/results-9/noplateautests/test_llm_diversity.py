import pytest
from pytutils.excs import ok

def test_iter2_1_ok_passes_specific_exception(monkeypatch):
    # Arrange
    def raise_value_error():
        raise ValueError("This is a ValueError")

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        raise_value_error()  # This should not raise an exception

def test_iter2_1_ok_raises_different_exception(monkeypatch):
    # Arrange
    def raise_type_error():
        raise TypeError("This is a TypeError")

    # Act & Assert
    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        raise_type_error()  # This should raise an exception

def test_iter2_1_ok_passes_no_exception(monkeypatch):
    # Arrange
    def no_exception():
        return "No Exception"

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        result = no_exception()  # This should not raise an exception
        assert result == "No Exception"

def test_iter2_1_ok_passes_multiple_exceptions(monkeypatch):
    # Arrange
    def raise_multiple_exceptions():
        raise ValueError("This is a ValueError")
    
    # Act & Assert
    with ok((ValueError, TypeError)):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        raise_multiple_exceptions()  # This should not raise an exception

def test_iter2_1_ok_raises_unexpected_exception(monkeypatch):
    # Arrange
    def raise_unexpected_exception():
        raise KeyError("This is a KeyError")

    # Act & Assert
    with pytest.raises(KeyError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        raise_unexpected_exception()  # This should raise an exception

def test_iter2_1_ok_with_context_manager(monkeypatch):
    # Arrange
    def raise_value_error():
        raise ValueError("This is a ValueError")

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        with pytest.raises(ValueError):
            raise_value_error()  # This should raise an exception within the context

def test_iter2_1_ok_with_nested_contexts(monkeypatch):
    # Arrange
    def raise_value_error():
        raise ValueError("This is a ValueError")

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        with ok(ValueError):
            raise_value_error()  # This should not raise an exception

def test_iter2_1_ok_with_non_exception_callable(monkeypatch):
    # Arrange
    def non_exception_callable():
        return "Just a callable"

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        result = non_exception_callable()  # This should not raise an exception
        assert result == "Just a callable"
