# file: pytutils.excs.py:4-15
# asked: {"lines": [15], "branches": [[12, 15]]}
# gained: {"lines": [15], "branches": [[12, 15]]}

import pytest
from pytutils.excs import ok

def test_ok_passes_specific_exception(monkeypatch):
    # This test should pass without raising an exception
    with ok(ValueError):
        raise ValueError("This is a ValueError")

def test_ok_raises_different_exception(monkeypatch):
    # This test should raise an exception since it's not a ValueError
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError("This is a TypeError")

def test_ok_passes_multiple_exceptions(monkeypatch):
    # This test should pass without raising an exception
    with ok(ValueError, KeyError):
        raise KeyError("This is a KeyError")

def test_ok_raises_unexpected_exception(monkeypatch):
    # This test should raise an exception since it's not a ValueError or KeyError
    with pytest.raises(IndexError):
        with ok(ValueError, KeyError):
            raise IndexError("This is an IndexError")
