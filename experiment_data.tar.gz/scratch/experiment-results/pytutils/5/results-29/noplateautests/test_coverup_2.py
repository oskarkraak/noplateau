# file: pytutils.excs.py:4-15
# asked: {"lines": [15], "branches": [[12, 15]]}
# gained: {"lines": [15], "branches": [[12, 15]]}

import pytest
from pytutils.excs import ok

class CustomException(Exception):
    pass

class AnotherException(Exception):
    pass

def test_ok_passes_specific_exception():
    """Test that the context manager passes a specific exception."""
    with ok(CustomException):
        raise CustomException("This should be passed.")

def test_ok_raises_different_exception():
    """Test that the context manager raises a different exception."""
    with pytest.raises(AnotherException):
        with ok(CustomException):
            raise AnotherException("This should not be passed.")
