# file: pytutils.excs.py:4-15
# asked: {"lines": [4, 5, 9, 10, 11, 12, 13, 15], "branches": [[12, 13], [12, 15]]}
# gained: {"lines": [4, 5, 9, 10, 11, 12, 13], "branches": [[12, 13]]}

import pytest
from pytutils.excs import ok

def test_ok_passes_specific_exception(monkeypatch):
    # Arrange
    def raise_value_error():
        raise ValueError("This is a ValueError")

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_value_error()  # This should not raise an exception

def test_ok_raises_different_exception(monkeypatch):
    # Arrange
    def raise_type_error():
        raise TypeError("This is a TypeError")

    # Act & Assert
    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_type_error()  # This should raise an exception
