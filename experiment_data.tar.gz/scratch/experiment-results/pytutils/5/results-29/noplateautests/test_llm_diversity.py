import pytest
from pytutils.excs import ok

def test_iter2_1_ok_passes_specific_exception(monkeypatch):
    # Arrange
    def raise_value_error():
        raise ValueError("This is a ValueError")

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_value_error()  # This should not raise an exception

def test_iter2_1_ok_raises_different_exception(monkeypatch):
    # Arrange
    def raise_type_error():
        raise TypeError("This is a TypeError")

    # Act & Assert
    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_type_error()  # This should raise an exception

def test_iter2_1_ok_passes_no_exception(monkeypatch):
    # Arrange
    def do_nothing():
        pass

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        do_nothing()  # This should not raise an exception

def test_iter2_1_ok_passes_multiple_exceptions(monkeypatch):
    # Arrange
    def raise_multiple_exceptions():
        raise ValueError("This is a ValueError")
        raise TypeError("This is a TypeError")  # This line will never be reached

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_multiple_exceptions()  # This should not raise an exception

def test_iter2_1_ok_raises_unexpected_exception(monkeypatch):
    # Arrange
    def raise_unexpected_exception():
        raise KeyError("This is a KeyError")

    # Act & Assert
    with pytest.raises(KeyError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_unexpected_exception()  # This should raise an exception

def test_iter2_1_ok_passes_with_side_effects(monkeypatch):
    # Arrange
    side_effect = []
    def raise_value_error_with_side_effect():
        side_effect.append("Side effect occurred")
        raise ValueError("This is a ValueError")

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_value_error_with_side_effect()  # This should not raise an exception
    assert side_effect == ["Side effect occurred"]

def test_iter2_1_ok_raises_exception_after_side_effect(monkeypatch):
    # Arrange
    side_effect = []
    def raise_type_error_with_side_effect():
        side_effect.append("Side effect occurred")
        raise TypeError("This is a TypeError")

    # Act & Assert
    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_type_error_with_side_effect()  # This should raise an exception
    assert side_effect == ["Side effect occurred"]
