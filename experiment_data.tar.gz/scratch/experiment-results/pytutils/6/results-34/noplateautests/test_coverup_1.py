# file: pytutils.excs.py:4-15
# asked: {"lines": [4, 5, 9, 10, 11, 12, 13, 15], "branches": [[12, 13], [12, 15]]}
# gained: {"lines": [4, 5, 9, 10, 11, 12, 13, 15], "branches": [[12, 13], [12, 15]]}

import pytest
from pytutils.excs import ok

def test_ok_passes_specific_exception():
    # Arrange
    class CustomException(Exception):
        pass

    # Act & Assert
    with ok(CustomException):
        # This should not raise an exception
        raise CustomException("This is a custom exception")

def test_ok_raises_unexpected_exception():
    # Arrange
    class CustomException(Exception):
        pass

    class AnotherException(Exception):
        pass

    # Act & Assert
    with pytest.raises(AnotherException):
        with ok(CustomException):
            # This should raise an unexpected exception
            raise AnotherException("This is another exception")

def test_ok_passes_multiple_exceptions():
    # Arrange
    class CustomException(Exception):
        pass

    class AnotherCustomException(Exception):
        pass

    # Act & Assert
    with ok(CustomException, AnotherCustomException):
        # This should not raise an exception
        raise AnotherCustomException("This is another custom exception")
