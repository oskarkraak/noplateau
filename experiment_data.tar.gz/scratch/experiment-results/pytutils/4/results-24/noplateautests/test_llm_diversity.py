import pytest
from pytutils.excs import ok

def test_iter2_1_ok_passes_specific_exception(monkeypatch):
    def raise_value_error():
        raise ValueError("This is a ValueError")

    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        raise_value_error()

def test_iter2_1_ok_raises_different_exception(monkeypatch):
    def raise_type_error():
        raise TypeError("This is a TypeError")

    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        raise_type_error()

def test_iter2_1_ok_passes_no_exception(monkeypatch):
    def no_exception():
        return "No Exception"

    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        result = no_exception()
        assert result == "No Exception"

def test_iter2_1_ok_passes_nested_exceptions(monkeypatch):
    def nested_exceptions():
        try:
            raise ValueError("This is a ValueError")
        except ValueError:
            raise TypeError("This is a TypeError")

    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        nested_exceptions()

def test_iter2_1_ok_passes_custom_exception(monkeypatch):
    class CustomException(Exception):
        pass

    def raise_custom_exception():
        raise CustomException("This is a Custom Exception")

    with pytest.raises(CustomException):
        monkeypatch.setattr("builtins.print", lambda x: None)
        raise_custom_exception()

def test_iter2_1_ok_passes_multiple_exceptions(monkeypatch):
    def raise_multiple_exceptions():
        raise ValueError("First Exception")
    
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        raise_multiple_exceptions()

    def raise_another_exception():
        raise TypeError("Second Exception")

    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        raise_another_exception()

    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        result = no_exception()
        assert result == "No Exception"

    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        raise_type_error()

def test_iter2_1_ok_passes_empty_exception(monkeypatch):
    def empty_exception():
        pass

    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        empty_exception()  # Should not raise any exception

def test_iter2_1_ok_passes_exception_in_finally(monkeypatch):
    def exception_in_finally():
        try:
            raise ValueError("This is a ValueError")
        finally:
            raise TypeError("This is a TypeError")

    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        exception_in_finally()

def test_iter5_3_ok_passes_specific_exception(monkeypatch):
    def raise_value_error():
        raise ValueError("This is a ValueError")

    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        raise_value_error()

def test_iter5_3_ok_raises_different_exception(monkeypatch):
    def raise_type_error():
        raise TypeError("This is a TypeError")

    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)
        raise_type_error()
