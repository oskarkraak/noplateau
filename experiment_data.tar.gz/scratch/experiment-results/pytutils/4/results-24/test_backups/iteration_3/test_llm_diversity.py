import pytest
from pytutils.excs import ok

def test_iter2_1_ok_passes_specific_exception(monkeypatch):
    # Arrange
    def raise_value_error():
        raise ValueError("This is a ValueError")

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        raise_value_error()  # This should not raise an error

def test_iter2_1_ok_raises_different_exception(monkeypatch):
    # Arrange
    def raise_type_error():
        raise TypeError("This is a TypeError")

    # Act & Assert
    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        raise_type_error()  # This should raise a TypeError

def test_iter2_1_ok_passes_no_exception(monkeypatch):
    # Arrange
    def no_exception():
        return "No Exception"

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        result = no_exception()  # This should not raise an error
        assert result == "No Exception"

    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        raise_type_error()  # This should raise a TypeError

def test_iter2_1_ok_passes_nested_exceptions(monkeypatch):
    # Arrange
    def nested_exceptions():
        try:
            raise ValueError("This is a ValueError")
        except ValueError:
            raise TypeError("This is a TypeError")

    # Act & Assert
    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        nested_exceptions()  # This should raise a TypeError

def test_iter2_1_ok_passes_custom_exception(monkeypatch):
    # Arrange
    class CustomException(Exception):
        pass

    def raise_custom_exception():
        raise CustomException("This is a Custom Exception")

    # Act & Assert
    with pytest.raises(CustomException):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid output
        raise_custom_exception()  # This should raise a CustomException
