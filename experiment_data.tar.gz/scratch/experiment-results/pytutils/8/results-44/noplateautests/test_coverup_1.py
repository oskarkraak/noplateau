# file: pytutils.excs.py:4-15
# asked: {"lines": [4, 5, 9, 10, 11, 12, 13, 15], "branches": [[12, 13], [12, 15]]}
# gained: {"lines": [4, 5, 9, 10, 11, 12, 13, 15], "branches": [[12, 13], [12, 15]]}

import pytest
from pytutils.excs import ok

def test_ok_passes_specific_exception(monkeypatch):
    # This test should pass without raising an exception
    with ok(ValueError):
        raise ValueError("This is a ValueError")

def test_ok_raises_different_exception(monkeypatch):
    # This test should raise a TypeError since it's not a ValueError
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError("This is a TypeError")

def test_ok_passes_multiple_exceptions(monkeypatch):
    # This test should pass without raising an exception
    with ok(ValueError, KeyError):
        raise KeyError("This is a KeyError")

def test_ok_raises_unexpected_exception(monkeypatch):
    # This test should raise a ValueError since it's not a KeyError
    with pytest.raises(ValueError):
        with ok(KeyError):
            raise ValueError("This is a ValueError")
