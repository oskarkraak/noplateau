import pytest
from pytutils.excs import ok

def test_iter2_1_ok_passes_specific_exception(monkeypatch):
    # Arrange
    def raise_value_error():
        raise ValueError("This is a ValueError")

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_value_error()  # This should not raise an exception

def test_iter2_1_ok_raises_different_exception(monkeypatch):
    # Arrange
    def raise_type_error():
        raise TypeError("This is a TypeError")

    # Act & Assert
    with pytest.raises(TypeError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_type_error()  # This should raise a TypeError

def test_iter2_1_ok_passes_no_exception(monkeypatch):
    # Arrange
    def do_nothing():
        pass

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        do_nothing()  # This should not raise an exception

def test_iter2_1_ok_passes_multiple_exceptions(monkeypatch):
    # Arrange
    def raise_value_error():
        raise ValueError("This is a ValueError")

    def raise_key_error():
        raise KeyError("This is a KeyError")

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_value_error()  # This should not raise an exception

    with pytest.raises(KeyError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_key_error()  # This should raise a KeyError

    # Act & Assert
    with ok(ValueError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        nested_exceptions()  # This should not raise an exception

def test_iter2_1_ok_raises_unexpected_exception(monkeypatch):
    # Arrange
    def raise_index_error():
        raise IndexError("This is an IndexError")

    # Act & Assert
    with pytest.raises(IndexError):
        monkeypatch.setattr("builtins.print", lambda x: None)  # Mock print to avoid side effects
        raise_index_error()  # This should raise an IndexError
