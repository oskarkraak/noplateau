# file: py_backwards.conf.py:12-14
# asked: {"lines": [13, 14], "branches": [[13, 0], [13, 14]]}
# gained: {"lines": [13, 14], "branches": [[13, 0], [13, 14]]}

import pytest
from argparse import Namespace
from py_backwards.conf import init_settings
from py_backwards.conf import settings

@pytest.fixture
def mock_settings(monkeypatch):
    class MockSettings:
        debug = False

    mock_settings_instance = MockSettings()
    monkeypatch.setattr('py_backwards.conf.settings', mock_settings_instance)
    return mock_settings_instance

def test_init_settings_debug_on(mock_settings):
    args = Namespace(debug=True)
    init_settings(args)
    assert mock_settings.debug is True

def test_init_settings_debug_off(mock_settings):
    args = Namespace(debug=False)
    init_settings(args)
    assert mock_settings.debug is False
