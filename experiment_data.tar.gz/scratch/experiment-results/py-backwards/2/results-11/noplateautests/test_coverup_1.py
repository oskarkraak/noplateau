# file: py_backwards.conf.py:4-6
# asked: {"lines": [4, 5, 6], "branches": []}
# gained: {"lines": [4, 5, 6], "branches": []}

import pytest
from py_backwards.conf import Settings

def test_settings_initialization():
    settings = Settings()
    assert settings.debug is False

def test_settings_debug_property(monkeypatch):
    settings = Settings()
    assert settings.debug is False

    # Change the debug property
    monkeypatch.setattr(settings, 'debug', True)
    assert settings.debug is True

    # Clean up by resetting the debug property
    settings.debug = False
    assert settings.debug is False
