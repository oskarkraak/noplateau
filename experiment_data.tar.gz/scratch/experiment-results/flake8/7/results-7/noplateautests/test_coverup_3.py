# file: flake8/flake8.main.debug.py:51-60
# asked: {"lines": [51, 53, 54, 55, 56, 57, 59], "branches": []}
# gained: {"lines": [51, 53, 54, 55, 56, 57, 59], "branches": []}

import pytest
from flake8.main.debug import plugins_from

class MockPlugin:
    def __init__(self, name, version, local):
        self.name = name
        self.version = version
        self.local = local

    def __lt__(self, other):
        return self.name < other.name

class MockOptionManager:
    def __init__(self, plugins):
        self.registered_plugins = plugins

def test_plugins_from_empty(monkeypatch):
    option_manager = MockOptionManager([])
    result = plugins_from(option_manager)
    assert result == []

def test_plugins_from_single_plugin(monkeypatch):
    plugin = MockPlugin("test_plugin", "1.0.0", False)
    option_manager = MockOptionManager([plugin])
    result = plugins_from(option_manager)
    assert len(result) == 1
    assert result[0] == {"plugin": "test_plugin", "version": "1.0.0", "is_local": False}

def test_plugins_from_multiple_plugins(monkeypatch):
    plugin1 = MockPlugin("plugin_a", "1.0.0", True)
    plugin2 = MockPlugin("plugin_b", "2.0.0", False)
    option_manager = MockOptionManager([plugin2, plugin1])
    result = plugins_from(option_manager)
    assert len(result) == 2
    assert result[0] == {"plugin": "plugin_a", "version": "1.0.0", "is_local": True}
    assert result[1] == {"plugin": "plugin_b", "version": "2.0.0", "is_local": False}
