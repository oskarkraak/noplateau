# file: flake8/flake8.main.debug.py:51-60
# asked: {"lines": [51, 53, 54, 55, 56, 57, 59], "branches": []}
# gained: {"lines": [51, 53, 54, 55, 56, 57, 59], "branches": []}

import pytest
from flake8.main.debug import plugins_from

class MockPlugin:
    def __init__(self, name, version, local):
        self.name = name
        self.version = version
        self.local = local

    def __lt__(self, other):
        return self.name < other.name

class MockOptionManager:
    def __init__(self, plugins):
        self.registered_plugins = plugins

def test_plugins_from_empty(monkeypatch):
    # Test with no plugins registered
    option_manager = MockOptionManager(plugins=[])
    result = plugins_from(option_manager)
    assert result == []

def test_plugins_from_single_plugin(monkeypatch):
    # Test with a single plugin registered
    plugin = MockPlugin(name="test_plugin", version="1.0.0", local=False)
    option_manager = MockOptionManager(plugins=[plugin])
    result = plugins_from(option_manager)
    assert result == [{'plugin': 'test_plugin', 'version': '1.0.0', 'is_local': False}]

def test_plugins_from_multiple_plugins(monkeypatch):
    # Test with multiple plugins registered
    plugin1 = MockPlugin(name="plugin_a", version="1.0.0", local=False)
    plugin2 = MockPlugin(name="plugin_b", version="2.0.0", local=True)
    option_manager = MockOptionManager(plugins=[plugin2, plugin1])
    result = plugins_from(option_manager)
    assert result == [
        {'plugin': 'plugin_a', 'version': '1.0.0', 'is_local': False},
        {'plugin': 'plugin_b', 'version': '2.0.0', 'is_local': True}
    ]
