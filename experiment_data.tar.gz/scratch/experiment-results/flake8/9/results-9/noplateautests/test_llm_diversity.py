import pytest
import platform
from flake8.main.debug import dependencies, information, plugins_from

def test_iter2_1_dependencies_empty():
    """Test that dependencies function returns an empty list."""
    result = dependencies()
    assert result == [], "Expected an empty list from dependencies()"

class MockOptionManager:
    def __init__(self, version):
        self.version = version

def test_iter2_2_information(monkeypatch):
    # Arrange
    mock_option_manager = MockOptionManager(version="1.0.0")
    
    # Mocking the plugins_from and dependencies functions
    monkeypatch.setattr("flake8.main.debug.plugins_from", lambda x: ["plugin1", "plugin2"])
    monkeypatch.setattr("flake8.main.debug.dependencies", lambda: ["dep1", "dep2"])

    # Act
    result = information(mock_option_manager)

    # Assert
    assert result["version"] == "1.0.0"
    assert result["plugins"] == ["plugin1", "plugin2"]
    assert result["dependencies"] == ["dep1", "dep2"]
    assert result["platform"]["python_implementation"] == platform.python_implementation()
    assert result["platform"]["python_version"] == platform.python_version()
    assert result["platform"]["system"] == platform.system()

def test_iter2_2_information_no_plugins(monkeypatch):
    """Test information function with no plugins."""
    mock_option_manager = MockOptionManager(version="1.0.0")
    monkeypatch.setattr("flake8.main.debug.plugins_from", lambda x: [])
    monkeypatch.setattr("flake8.main.debug.dependencies", lambda: ["dep1"])

    result = information(mock_option_manager)

    assert result["version"] == "1.0.0"
    assert result["plugins"] == []
    assert result["dependencies"] == ["dep1"]

def test_iter2_2_information_no_dependencies(monkeypatch):
    """Test information function with no dependencies."""
    mock_option_manager = MockOptionManager(version="1.0.0")
    monkeypatch.setattr("flake8.main.debug.plugins_from", lambda x: ["plugin1"])
    monkeypatch.setattr("flake8.main.debug.dependencies", lambda: [])

    result = information(mock_option_manager)

    assert result["version"] == "1.0.0"
    assert result["plugins"] == ["plugin1"]
    assert result["dependencies"] == []

class MockPlugin:
    def __init__(self, name, version, local):
        self.name = name
        self.version = version
        self.local = local

    def __lt__(self, other):
        return self.name < other.name

class MockOptionManagerForPlugins:
    def __init__(self, plugins):
        self.registered_plugins = plugins

def test_iter2_3_plugins_from_empty(monkeypatch):
    # Test with no plugins registered
    option_manager = MockOptionManagerForPlugins(plugins=[])
    result = plugins_from(option_manager)
    assert result == []

def test_iter2_3_plugins_from_single_plugin(monkeypatch):
    # Test with a single plugin registered
    plugin = MockPlugin(name="test_plugin", version="1.0.0", local=False)
    option_manager = MockOptionManagerForPlugins(plugins=[plugin])
    result = plugins_from(option_manager)
    assert result == [{'plugin': 'test_plugin', 'version': '1.0.0', 'is_local': False}]

def test_iter2_3_plugins_from_multiple_plugins(monkeypatch):
    # Test with multiple plugins registered
    plugin1 = MockPlugin(name="plugin_a", version="1.0.0", local=False)
    plugin2 = MockPlugin(name="plugin_b", version="2.0.0", local=True)
    option_manager = MockOptionManagerForPlugins(plugins=[plugin2, plugin1])
    result = plugins_from(option_manager)
    assert result == [
        {'plugin': 'plugin_a', 'version': '1.0.0', 'is_local': False},
        {'plugin': 'plugin_b', 'version': '2.0.0', 'is_local': True}
    ]

def test_iter2_3_plugins_from_duplicate_plugins(monkeypatch):
    # Test with duplicate plugins registered
    plugin1 = MockPlugin(name="plugin_a", version="1.0.0", local=False)
    plugin2 = MockPlugin(name="plugin_a", version="1.0.0", local=True)  # Duplicate name
    option_manager = MockOptionManagerForPlugins(plugins=[plugin1, plugin2])
    result = plugins_from(option_manager)
    assert result == [
        {'plugin': 'plugin_a', 'version': '1.0.0', 'is_local': False},
        {'plugin': 'plugin_a', 'version': '1.0.0', 'is_local': True}
    ]
