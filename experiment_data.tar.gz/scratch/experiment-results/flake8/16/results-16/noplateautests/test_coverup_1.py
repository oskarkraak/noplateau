# file: flake8/flake8.main.debug.py:63-65
# asked: {"lines": [63, 65], "branches": []}
# gained: {"lines": [63, 65], "branches": []}

import pytest
from flake8.main.debug import dependencies

def test_dependencies_empty():
    """Test that dependencies returns an empty list."""
    result = dependencies()
    assert result == []

def test_dependencies_no_side_effects(monkeypatch):
    """Test that dependencies does not affect any external state."""
    # Here we can check if any external state is modified, but since
    # dependencies() is a pure function, we can just call it.
    result = dependencies()
    assert result == []
