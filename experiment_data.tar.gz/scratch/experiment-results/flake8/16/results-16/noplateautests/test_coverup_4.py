# file: flake8/flake8.main.debug.py:10-34
# asked: {"lines": [10, 11, 13, 19, 20, 22, 27, 28, 29, 30, 31, 34], "branches": [[27, 28], [27, 29]]}
# gained: {"lines": [10, 11, 13, 19, 20, 22, 27, 28, 29, 30, 31, 34], "branches": [[27, 28], [27, 29]]}

import argparse
import json
import pytest
import platform
from flake8.main.debug import DebugAction

class MockOptionManager:
    def __init__(self, registered_plugins):
        self.registered_plugins = registered_plugins
        self.version = "1.0.0"

class MockPlugin:
    def __init__(self, name, version, local=False):
        self.name = name
        self.version = version
        self.local = local

    def __lt__(self, other):
        return self.name < other.name

def test_debug_action_with_no_plugins(monkeypatch):
    option_manager = MockOptionManager(registered_plugins=[])
    action = DebugAction(option_strings=['--debug'], dest='debug', option_manager=option_manager)

    # Call the action
    action(None, None, None)

    # No output expected since there are no registered plugins
    # We can check that SystemExit is not raised
    assert True  # Just to ensure the test runs without error

def test_debug_action_with_plugins(monkeypatch, capsys):
    registered_plugins = [MockPlugin("plugin1", "1.0"), MockPlugin("plugin2", "2.0")]
    option_manager = MockOptionManager(registered_plugins=registered_plugins)
    action = DebugAction(option_strings=['--debug'], dest='debug', option_manager=option_manager)

    # Call the action and handle SystemExit
    with pytest.raises(SystemExit):
        action(None, None, None)

    # Capture the output
    captured = capsys.readouterr()
    expected_output = json.dumps({
        'version': "1.0.0",
        'plugins': [{'plugin': 'plugin1', 'version': '1.0', 'is_local': False},
                    {'plugin': 'plugin2', 'version': '2.0', 'is_local': False}],
        'dependencies': [],
        'platform': {
            'python_implementation': platform.python_implementation(),
            'python_version': platform.python_version(),
            'system': platform.system()
        }
    }, indent=2, sort_keys=True)

    assert captured.out.strip() == expected_output
