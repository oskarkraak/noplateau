import pytest
import platform
from flake8.main.debug import information, plugins_from, dependencies

class MockOptionManager:
    def __init__(self, version=None, plugins=None):
        self.version = version
        self.registered_plugins = plugins if plugins is not None else []

class MockPlugin:
    def __init__(self, name, version, local):
        self.name = name
        self.version = version
        self.local = local

    def __lt__(self, other):
        return self.name < other.name

def test_information_with_valid_option_manager(monkeypatch):
    mock_option_manager = MockOptionManager(version="1.0.0")
    monkeypatch.setattr("flake8.main.debug.plugins_from", lambda x: ["plugin1", "plugin2"])
    monkeypatch.setattr("flake8.main.debug.dependencies", lambda: ["dep1", "dep2"])

    result = information(mock_option_manager)

    assert result["version"] == "1.0.0"
    assert result["plugins"] == ["plugin1", "plugin2"]
    assert result["dependencies"] == ["dep1", "dep2"]
    assert result["platform"]["python_implementation"] == platform.python_implementation()
    assert result["platform"]["python_version"] == platform.python_version()
    assert result["platform"]["system"] == platform.system()

def test_plugins_from_empty():
    option_manager = MockOptionManager()
    result = plugins_from(option_manager)
    assert result == []

def test_plugins_from_single_plugin():
    plugin = MockPlugin("test_plugin", "1.0.0", False)
    option_manager = MockOptionManager(plugins=[plugin])
    result = plugins_from(option_manager)
    assert result == [{"plugin": "test_plugin", "version": "1.0.0", "is_local": False}]

def test_plugins_from_multiple_plugins():
    plugin1 = MockPlugin("plugin_a", "1.0.0", True)
    plugin2 = MockPlugin("plugin_b", "2.0.0", False)
    option_manager = MockOptionManager(plugins=[plugin2, plugin1])
    result = plugins_from(option_manager)
    assert result == [
        {"plugin": "plugin_a", "version": "1.0.0", "is_local": True},
        {"plugin": "plugin_b", "version": "2.0.0", "is_local": False},
    ]

def test_plugins_from_invalid_plugin_type():
    class InvalidPlugin:
        pass
    option_manager = MockOptionManager(plugins=[InvalidPlugin()])
    with pytest.raises(AttributeError):
        plugins_from(option_manager)

def test_dependencies_empty():
    result = dependencies()
    assert result == []

def test_dependencies_type():
    result = dependencies()
    assert isinstance(result, list)

def test_dependencies_with_none_option_manager():
    with pytest.raises(TypeError):
        dependencies(None)

def test_information_with_no_plugins(monkeypatch):
    mock_option_manager = MockOptionManager(version="1.0.0")
    monkeypatch.setattr("flake8.main.debug.plugins_from", lambda x: [])
    monkeypatch.setattr("flake8.main.debug.dependencies", lambda: ["dep1", "dep2"])

    result = information(mock_option_manager)

    assert result["version"] == "1.0.0"
    assert result["plugins"] == []
    assert result["dependencies"] == ["dep1", "dep2"]

def test_plugins_from_with_local_plugins():
    plugin1 = MockPlugin("local_plugin", "1.0.0", True)
    plugin2 = MockPlugin("remote_plugin", "2.0.0", False)
    option_manager = MockOptionManager(plugins=[plugin1, plugin2])
    result = plugins_from(option_manager)
    assert result == [
        {"plugin": "local_plugin", "version": "1.0.0", "is_local": True},
        {"plugin": "remote_plugin", "version": "2.0.0", "is_local": False},
    ]

def test_information_with_different_python_versions(monkeypatch):
    mock_option_manager = MockOptionManager(version="2.0.0")
    monkeypatch.setattr("flake8.main.debug.plugins_from", lambda x: ["plugin3"])
    monkeypatch.setattr("flake8.main.debug.dependencies", lambda: ["dep3"])

    result = information(mock_option_manager)

    assert result["version"] == "2.0.0"
    assert result["plugins"] == ["plugin3"]
    assert result["dependencies"] == ["dep3"]
    assert result["platform"]["python_implementation"] == platform.python_implementation()
    assert result["platform"]["python_version"] == platform.python_version()
    assert result["platform"]["system"] == platform.system()
