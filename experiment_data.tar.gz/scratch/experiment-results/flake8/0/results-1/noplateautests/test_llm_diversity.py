import pytest
from flake8.options.aggregator import aggregate_options

