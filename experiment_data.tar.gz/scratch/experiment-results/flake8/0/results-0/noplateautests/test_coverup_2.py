# file: flake8/main/debug.py:37-48
# asked: {"lines": [37, 39, 40, 41, 42, 43, 44, 45, 46], "branches": []}
# gained: {"lines": [37, 39, 40, 41, 42, 43, 44, 45, 46], "branches": []}

import pytest
import platform
from main.debug import information

class MockOptionManager:
    def __init__(self, version):
        self.version = version

def test_information(monkeypatch):
    # Arrange
    mock_option_manager = MockOptionManager(version="1.0.0")
    
    # Mocking the plugins_from and dependencies functions
    monkeypatch.setattr("main.debug.plugins_from", lambda x: ["plugin1", "plugin2"])
    monkeypatch.setattr("main.debug.dependencies", lambda: ["dep1", "dep2"])

    # Act
    result = information(mock_option_manager)

    # Assert
    assert result["version"] == "1.0.0"
    assert result["plugins"] == ["plugin1", "plugin2"]
    assert result["dependencies"] == ["dep1", "dep2"]
    assert result["platform"]["python_implementation"] == platform.python_implementation()
    assert result["platform"]["python_version"] == platform.python_version()
    assert result["platform"]["system"] == platform.system()
