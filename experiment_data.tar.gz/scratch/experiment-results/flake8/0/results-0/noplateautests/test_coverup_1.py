# file: flake8/main/debug.py:63-65
# asked: {"lines": [63, 65], "branches": []}
# gained: {"lines": [63, 65], "branches": []}

import pytest
from main.debug import dependencies

def test_dependencies_empty():
    """Test that dependencies returns an empty list."""
    result = dependencies()
    assert result == []

def test_dependencies_type():
    """Test that dependencies returns a list."""
    result = dependencies()
    assert isinstance(result, list)
