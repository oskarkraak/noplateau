import pytest
import platform
from main.debug import dependencies, information, plugins_from

# Test cases for dependencies function
def test_iter2_1_dependencies_empty():
    """Test that dependencies returns an empty list."""
    result = dependencies()
    assert result == []

def test_iter2_1_dependencies_type():
    """Test that dependencies returns a list."""
    result = dependencies()
    assert isinstance(result, list)

# Test cases for information function
class MockOptionManager:
    def __init__(self, version):
        self.version = version

def test_iter2_2_information(monkeypatch):
    # Arrange
    mock_option_manager = MockOptionManager(version="1.0.0")
    
    # Mocking the plugins_from and dependencies functions
    monkeypatch.setattr("main.debug.plugins_from", lambda x: ["plugin1", "plugin2"])
    monkeypatch.setattr("main.debug.dependencies", lambda: ["dep1", "dep2"])

    # Act
    result = information(mock_option_manager)

    # Assert
    assert result["version"] == "1.0.0"
    assert result["plugins"] == ["plugin1", "plugin2"]
    assert result["dependencies"] == ["dep1", "dep2"]
    assert result["platform"]["python_implementation"] == platform.python_implementation()
    assert result["platform"]["python_version"] == platform.python_version()
    assert result["platform"]["system"] == platform.system()

# Test cases for plugins_from function
class MockPlugin:
    def __init__(self, name, version, local):
        self.name = name
        self.version = version
        self.local = local

class MockOptionManager:
    def __init__(self, plugins):
        self.registered_plugins = plugins

def test_iter2_3_plugins_from_empty(monkeypatch):
    option_manager = MockOptionManager([])
    result = plugins_from(option_manager)
    assert result == []

def test_iter2_3_plugins_from_single_plugin(monkeypatch):
    plugin = MockPlugin("test_plugin", "1.0.0", False)
    option_manager = MockOptionManager([plugin])
    result = plugins_from(option_manager)
    assert len(result) == 1
    assert result[0] == {"plugin": "test_plugin", "version": "1.0.0", "is_local": False}

def test_iter2_3_plugins_from_multiple_plugins(monkeypatch):
    plugin1 = MockPlugin("plugin_a", "1.0.0", False)
    plugin2 = MockPlugin("plugin_b", "2.0.0", True)
    option_manager = MockOptionManager([plugin2, plugin1])
    result = plugins_from(option_manager)
    assert len(result) == 2
    assert result[0] == {"plugin": "plugin_a", "version": "1.0.0", "is_local": False}
    assert result[1] == {"plugin": "plugin_b", "version": "2.0.0", "is_local": True}

def test_iter2_3_plugins_from_duplicate_plugins(monkeypatch):
    plugin1 = MockPlugin("plugin_a", "1.0.0", False)
    plugin2 = MockPlugin("plugin_a", "1.0.0", True)  # Duplicate name, different local status
    option_manager = MockOptionManager([plugin1, plugin2])
    result = plugins_from(option_manager)
    assert len(result) == 2
    assert result[0] == {"plugin": "plugin_a", "version": "1.0.0", "is_local": False}
    assert result[1] == {"plugin": "plugin_a", "version": "1.0.0", "is_local": True}

def test_iter2_3_plugins_from_unordered_plugins(monkeypatch):
    plugin1 = MockPlugin("plugin_b", "2.0.0", True)
    plugin2 = MockPlugin("plugin_a", "1.0.0", False)
    option_manager = MockOptionManager([plugin1, plugin2])
    result = plugins_from(option_manager)
    assert len(result) == 2
    assert result[0] == {"plugin": "plugin_a", "version": "1.0.0", "is_local": False}
    assert result[1] == {"plugin": "plugin_b", "version": "2.0.0", "is_local": True}
