import pytest
from flake8.options.aggregator import aggregate_options

    with pytest.raises(TypeError):
        aggregate_options([], {}, {})

    with pytest.raises(TypeError):
        aggregate_options({}, {}, [])

