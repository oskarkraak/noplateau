import pytest
import platform
from flake8.main.debug import dependencies, information, plugins_from

# Test cases for dependencies function
def test_dependencies_empty():
    """Test that dependencies returns an empty list."""
    result = dependencies()
    assert result == []

def test_dependencies_type():
    """Test that dependencies returns a list."""
    result = dependencies()
    assert isinstance(result, list)

# Test cases for information function
class MockOptionManager:
    def __init__(self, version):
        self.version = version

def test_information_valid_version(monkeypatch):
    mock_option_manager = MockOptionManager(version="1.0.0")
    monkeypatch.setattr("flake8.main.debug.plugins_from", lambda x: ["plugin1", "plugin2"])
    monkeypatch.setattr("flake8.main.debug.dependencies", lambda: ["dep1", "dep2"])

    result = information(mock_option_manager)

    assert result["version"] == "1.0.0"
    assert result["plugins"] == ["plugin1", "plugin2"]
    assert result["dependencies"] == ["dep1", "dep2"]
    assert result["platform"]["python_implementation"] == platform.python_implementation()
    assert result["platform"]["python_version"] == platform.python_version()
    assert result["platform"]["system"] == platform.system()

def test_information_no_plugins(monkeypatch):
    mock_option_manager = MockOptionManager(version="1.0.0")
    monkeypatch.setattr("flake8.main.debug.plugins_from", lambda x: [])
    monkeypatch.setattr("flake8.main.debug.dependencies", lambda: ["dep1", "dep2"])

    result = information(mock_option_manager)

    assert result["version"] == "1.0.0"
    assert result["plugins"] == []
    assert result["dependencies"] == ["dep1", "dep2"]

def test_information_no_dependencies(monkeypatch):
    mock_option_manager = MockOptionManager(version="1.0.0")
    monkeypatch.setattr("flake8.main.debug.plugins_from", lambda x: ["plugin1", "plugin2"])
    monkeypatch.setattr("flake8.main.debug.dependencies", lambda: [])

    result = information(mock_option_manager)

    assert result["version"] == "1.0.0"
    assert result["plugins"] == ["plugin1", "plugin2"]
    assert result["dependencies"] == []

# Test cases for plugins_from function
class MockPlugin:
    def __init__(self, name, version, local):
        self.name = name
        self.version = version
        self.local = local

class MockOptionManagerWithPlugins:
    def __init__(self, plugins):
        self.registered_plugins = plugins

def test_plugins_from_empty(monkeypatch):
    option_manager = MockOptionManagerWithPlugins([])
    result = plugins_from(option_manager)
    assert result == []

def test_plugins_from_single_plugin(monkeypatch):
    plugin = MockPlugin("plugin1", "1.0.0", False)
    option_manager = MockOptionManagerWithPlugins([plugin])
    result = plugins_from(option_manager)
    assert len(result) == 1
    assert result[0] == {"plugin": "plugin1", "version": "1.0.0", "is_local": False}

def test_plugins_from_no_version(monkeypatch):
    plugin = MockPlugin("plugin1", None, False)
    option_manager = MockOptionManagerWithPlugins([plugin])
    result = plugins_from(option_manager)
    assert len(result) == 1
    assert result[0] == {"plugin": "plugin1", "version": None, "is_local": False}

def test_plugins_from_local_plugin(monkeypatch):
    plugin = MockPlugin("plugin1", "1.0.0", True)
    option_manager = MockOptionManagerWithPlugins([plugin])
    result = plugins_from(option_manager)
    assert len(result) == 1
    assert result[0] == {"plugin": "plugin1", "version": "1.0.0", "is_local": True}
