import pytest
import platform
from flake8.main.debug import dependencies, information, plugins_from

# Test cases for dependencies function
def test_iter2_1_dependencies_empty():
    """Test that dependencies returns an empty list."""
    result = dependencies()
    assert result == []

def test_iter2_1_dependencies_type():
    """Test that dependencies returns a list."""
    result = dependencies()
    assert isinstance(result, list)

# Test cases for information function
class MockOptionManager:
    def __init__(self, version):
        self.version = version

    # Act
    result = information(mock_option_manager)

    # Assert
    assert result["version"] == "1.0.0"
    assert result["plugins"] == ["plugin1", "plugin2"]
    assert result["dependencies"] == ["dep1", "dep2"]
    assert result["platform"]["python_implementation"] == platform.python_implementation()
    assert result["platform"]["python_version"] == platform.python_version()
    assert result["platform"]["system"] == platform.system()

# Test cases for plugins_from function
class MockPlugin:
    def __init__(self, name, version, local):
        self.name = name
        self.version = version
        self.local = local

class MockOptionManager:
    def __init__(self, plugins):
        self.registered_plugins = plugins

def test_iter2_3_plugins_from_empty(monkeypatch):
    option_manager = MockOptionManager([])
    result = plugins_from(option_manager)
    assert result == []

def test_iter2_3_plugins_from_single_plugin(monkeypatch):
    plugin = MockPlugin("plugin1", "1.0.0", False)
    option_manager = MockOptionManager([plugin])
    result = plugins_from(option_manager)
    assert len(result) == 1
    assert result[0] == {"plugin": "plugin1", "version": "1.0.0", "is_local": False}

def test_iter2_3_plugins_from_no_version(monkeypatch):
    plugin = MockPlugin("plugin1", None, False)
    option_manager = MockOptionManager([plugin])
    result = plugins_from(option_manager)
    assert len(result) == 1
    assert result[0] == {"plugin": "plugin1", "version": None, "is_local": False}

