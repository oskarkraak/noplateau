# file: semantic_release.dist.py:20-22
# asked: {"lines": [20, 21, 22], "branches": []}
# gained: {"lines": [20, 21, 22], "branches": []}

import pytest
from semantic_release.dist import should_remove_dist
from semantic_release.settings import config

@pytest.fixture(autouse=True)
def mock_config(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: None)

def test_should_remove_dist_false_when_no_remove_dist():
    assert not should_remove_dist()

def test_should_remove_dist_false_when_remove_dist_false():
    config.get = lambda key: False if key == "remove_dist" else None
    assert not should_remove_dist()

def test_should_remove_dist_true_when_remove_dist_true_and_should_build_true():
    config.get = lambda key: True if key == "remove_dist" else True
    assert should_remove_dist()

def test_should_remove_dist_false_when_remove_dist_true_and_should_build_false():
    config.get = lambda key: True if key == "remove_dist" else False
    assert not should_remove_dist()
