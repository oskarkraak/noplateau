import pytest
from semantic_release.dist import should_remove_dist, should_build
from semantic_release.settings import config

@pytest.fixture(autouse=True)
def mock_config(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: None)

# Tests for should_remove_dist
def test_should_remove_dist_none():
    assert not should_remove_dist()

def test_should_remove_dist_true_when_remove_dist_true_and_should_build_true(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: True if key == "remove_dist" else True)
    monkeypatch.setattr('semantic_release.dist.should_build', lambda: True)
    assert should_remove_dist()

def test_should_remove_dist_edge_case_empty(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: None)
    assert not should_remove_dist()

def test_should_remove_dist_edge_case_unexpected_value(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: "unexpected_value" if key == "remove_dist" else None)
    assert not should_remove_dist()

# Tests for should_build
@pytest.fixture
def mock_build_config(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "build"
    }.get(key))

def test_should_build_with_valid_command_and_upload_pypi(mock_build_config):
    assert should_build() is True

def test_should_build_with_valid_command_and_upload_release(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "build"
    }.get(key))
    assert should_build() is True

def test_should_not_build_with_false_command(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "false"
    }.get(key))
    assert should_build() is False

def test_should_not_build_with_no_upload(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "build"
    }.get(key))
    assert should_build() is False

def test_should_not_build_with_empty_command(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": ""
    }.get(key))
    assert should_build() is False

def test_should_not_build_with_none_command(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": None
    }.get(key))
    assert should_build() is False

