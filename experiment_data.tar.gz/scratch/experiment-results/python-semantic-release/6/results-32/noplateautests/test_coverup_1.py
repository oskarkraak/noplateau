# file: semantic_release.dist.py:20-22
# asked: {"lines": [20, 21, 22], "branches": []}
# gained: {"lines": [20, 21, 22], "branches": []}

import pytest
from semantic_release.dist import should_remove_dist
from unittest.mock import patch

@pytest.fixture
def mock_config_remove_dist_true():
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            'remove_dist': True,
            'upload_to_pypi': True,
            'upload_to_release': False,
            'build_command': 'build'
        }.get(key, None)
        yield

@pytest.fixture
def mock_config_remove_dist_false():
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            'remove_dist': False,
            'upload_to_pypi': True,
            'upload_to_release': False,
            'build_command': 'build'
        }.get(key, None)
        yield

@pytest.fixture
def mock_config_no_build_command():
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            'remove_dist': True,
            'upload_to_pypi': True,
            'upload_to_release': False,
            'build_command': 'false'
        }.get(key, None)
        yield

def test_should_remove_dist_true(mock_config_remove_dist_true):
    assert should_remove_dist() is True

def test_should_remove_dist_false(mock_config_remove_dist_false):
    assert should_remove_dist() is False

def test_should_remove_dist_no_build_command(mock_config_no_build_command):
    assert should_remove_dist() is False
