import pytest
from semantic_release.dist import should_remove_dist, should_build
from unittest.mock import patch

# Tests for should_remove_dist function
@pytest.fixture
def mock_config_remove_dist_true():
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            'remove_dist': True,
            'upload_to_pypi': True,
            'upload_to_release': False,
            'build_command': 'build'
        }.get(key, None)
        yield

@pytest.fixture
def mock_config_remove_dist_false():
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            'remove_dist': False,
            'upload_to_pypi': True,
            'upload_to_release': False,
            'build_command': 'build'
        }.get(key, None)
        yield

@pytest.fixture
def mock_config_no_build_command():
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            'remove_dist': True,
            'upload_to_pypi': True,
            'upload_to_release': False,
            'build_command': 'false'
        }.get(key, None)
        yield

def test_should_remove_dist_true(mock_config_remove_dist_true):
    assert should_remove_dist() is True

def test_should_remove_dist_false(mock_config_remove_dist_false):
    assert should_remove_dist() is False

def test_should_remove_dist_no_build_command(mock_config_no_build_command):
    assert should_remove_dist() is False

def test_should_remove_dist_edge_case_empty_config():
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: None
        assert should_remove_dist() is False

# Tests for should_build function
@pytest.fixture
def mock_config_valid():
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            "upload_to_pypi": True,
            "upload_to_release": False,
            "build_command": "build"
        }.get(key)
        yield

def test_should_build_with_valid_command_and_upload_pypi(mock_config_valid):
    assert should_build() is True

def test_should_build_with_valid_command_and_upload_release(mock_config_valid):
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            "upload_to_pypi": False,
            "upload_to_release": True,
            "build_command": "build"
        }.get(key)
        assert should_build() is True

def test_should_not_build_with_false_command(mock_config_valid):
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            "upload_to_pypi": True,
            "upload_to_release": False,
            "build_command": "false"
        }.get(key)
        assert should_build() is False

def test_should_not_build_with_no_uploads(mock_config_valid):
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            "upload_to_pypi": False,
            "upload_to_release": False,
            "build_command": "build"
        }.get(key)
        assert should_build() is False

def test_should_not_build_with_empty_build_command(mock_config_valid):
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: {
            "upload_to_pypi": True,
            "upload_to_release": False,
            "build_command": ""
        }.get(key)
        assert should_build() is False

def test_should_build_edge_case_empty_config():
    with patch('semantic_release.settings.config.get') as mock_get:
        mock_get.side_effect = lambda key: None
        assert should_build() is False
