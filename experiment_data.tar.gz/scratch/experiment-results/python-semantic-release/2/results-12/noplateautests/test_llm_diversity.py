import pytest
from semantic_release.dist import should_build, should_remove_dist
from semantic_release.settings import config

@pytest.fixture
def mock_config(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "build"
    }.get(key))

# Tests for should_build function
def test_should_build_with_valid_command_and_upload_pypi(mock_config):
    assert should_build() is True

def test_should_build_with_valid_command_and_upload_release(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "build"
    }.get(key))
    assert should_build() is True

def test_should_not_build_with_no_upload(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "build"
    }.get(key))
    assert should_build() is False

def test_should_not_build_with_empty_command(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": ""
    }.get(key))
    assert should_build() is False

def test_should_not_build_with_none_command(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": None
    }.get(key))
    assert should_build() is False

# Tests for should_remove_dist function
@pytest.fixture(autouse=True)
def mock_config_remove_dist(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: None)

def test_should_remove_dist_false_when_remove_dist_is_none(mock_config_remove_dist):
    assert not should_remove_dist()

def test_should_remove_dist_false_when_remove_dist_is_false(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: False if key == "remove_dist" else None)
    assert not should_remove_dist()

def test_should_remove_dist_true_when_remove_dist_is_true_and_should_build_true(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: True if key == "remove_dist" else 'some_command' if key == "build_command" else None)
    monkeypatch.setattr('semantic_release.dist.should_build', lambda: True)
    assert should_remove_dist()

def test_should_remove_dist_false_when_remove_dist_is_true_and_should_build_false(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: True if key == "remove_dist" else 'false' if key == "build_command" else None)
    monkeypatch.setattr('semantic_release.dist.should_build', lambda: False)
    assert not should_remove_dist()

def test_should_remove_dist_false_when_remove_dist_is_empty_string(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: '' if key == "remove_dist" else None)
    assert not should_remove_dist()

def test_should_remove_dist_false_when_remove_dist_is_none_and_build_command_is_none(monkeypatch):
    monkeypatch.setattr(config, 'get', lambda key: None if key == "remove_dist" else None)
    monkeypatch.setattr('semantic_release.dist.should_build', lambda: False)
    assert not should_remove_dist()
