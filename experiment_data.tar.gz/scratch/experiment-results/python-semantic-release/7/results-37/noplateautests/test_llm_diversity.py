import pytest
import semantic_release.dist as module_0
from semantic_release.dist import should_build

@pytest.fixture
def mock_config(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "build"
    }.get(key))

def test_should_remove_dist_default():
    assert module_0.should_remove_dist() is True

def test_should_build_with_valid_command_and_upload_pypi(mock_config):
    assert should_build() is True

def test_should_build_with_valid_command_and_upload_release(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": False,
        "upload_to_release": True,
        "build_command": "build"
    }.get(key))
    assert should_build() is True

def test_should_not_build_with_false_command(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": "false"
    }.get(key))
    assert should_build() is False

def test_should_not_build_with_no_upload(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "build"
    }.get(key))
    assert should_build() is False

def test_should_not_build_with_empty_command(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": ""
    }.get(key))
    assert should_build() is False

def test_should_not_build_with_none_command(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": False,
        "build_command": None
    }.get(key))
    assert should_build() is False

def test_should_build_with_both_uploads_enabled(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "build"
    }.get(key))
    assert should_build() is True

def test_should_not_build_with_both_uploads_disabled(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "build"
    }.get(key))
    assert should_build() is False

def test_should_build_with_valid_command_and_no_uploads(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": False,
        "upload_to_release": False,
        "build_command": "build"
    }.get(key))
    assert should_build() is False

def test_should_build_with_valid_command_and_both_uploads(monkeypatch):
    monkeypatch.setattr('semantic_release.settings.config.get', lambda key: {
        "upload_to_pypi": True,
        "upload_to_release": True,
        "build_command": "build"
    }.get(key))
    assert should_build() is True

