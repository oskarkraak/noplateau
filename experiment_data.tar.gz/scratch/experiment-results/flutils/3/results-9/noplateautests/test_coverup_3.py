# file: flutils.decorators.py:57-59
# asked: {"lines": [57, 58, 59], "branches": []}
# gained: {"lines": [57, 58, 59], "branches": []}

import pytest
from flutils.decorators import cached_property

def test_cached_property_init():
    def sample_function():
        """This is a sample function."""
        return 42

    # Create an instance of cached_property
    cached_prop = cached_property(sample_function)

    # Assert that the __doc__ attribute is set correctly
    assert cached_prop.__doc__ == "This is a sample function."
    # Assert that the func attribute is set correctly
    assert cached_prop.func == sample_function

def test_cached_property_with_monkeypatch():
    def sample_function():
        """This is another sample function."""
        return 24

    # Create an instance of cached_property
    cached_prop = cached_property(sample_function)

    # Assert that the __doc__ attribute is initially correct
    assert cached_prop.__doc__ == "This is another sample function."

    # Use monkeypatch to change the function's __doc__ attribute
    def modified_function():
        """Modified docstring."""
        return 24

    # Update the cached_property instance with the modified function
    cached_prop.func = modified_function
    cached_prop.__doc__ = getattr(modified_function, '__doc__')

    # Assert that the __doc__ attribute is updated
    assert cached_prop.__doc__ == "Modified docstring."
