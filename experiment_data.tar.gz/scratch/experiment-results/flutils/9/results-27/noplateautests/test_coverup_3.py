# file: flutils.decorators.py:61-69
# asked: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}
# gained: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}

import asyncio
import pytest
from flutils.decorators import cached_property

class TestCachedProperty:
    def test_get_with_none_obj(self):
        prop = cached_property(lambda self: "value")
        assert prop.__get__(None, None) is prop

    def test_get_with_coroutine_function(self):
        async def async_func(self):
            return "async value"

        class TestClass:
            @cached_property
            async def prop(self):
                return await async_func(self)

        instance = TestClass()
        result = asyncio.run(instance.prop)
        assert result == "async value"

    def test_get_with_regular_function(self):
        def regular_func(self):
            return "regular value"

        class TestClass:
            @cached_property
            def prop(self):
                return regular_func(self)

        instance = TestClass()
        result = instance.prop
        assert result == "regular value"
        assert instance.__dict__['prop'] == "regular value"
