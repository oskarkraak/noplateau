# file: flutils.decorators.py:61-69
# asked: {"lines": [62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}
# gained: {"lines": [62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    def test_cached_property_with_none_obj(self):
        """Test that when obj is None, the cached_property returns itself."""
        prop = cached_property(lambda self: 42)
        assert prop.__get__(None, None) is prop

    def test_cached_property_with_coroutine_function(self):
        """Test that if the function is a coroutine, it is wrapped correctly."""
        async def async_func(self):
            return 42

        prop = cached_property(async_func)

        class TestClass:
            pass

        obj = TestClass()

        # Manually set the function to the object
        setattr(obj, 'async_func', async_func)

        # Run the coroutine and check the result
        result = asyncio.run(prop.__get__(obj, TestClass))
        assert result == 42

    def test_cached_property_with_regular_function(self):
        """Test that if the function is a regular function, it caches the result."""
        def regular_func(self):
            return 42

        prop = cached_property(regular_func)

        class TestClass:
            pass

        obj = TestClass()

        # First call should compute and cache the value
        value = prop.__get__(obj, TestClass)
        assert value == 42
        assert obj.__dict__[regular_func.__name__] == 42

        # Second call should return the cached value
        cached_value = prop.__get__(obj, TestClass)
        assert cached_value == 42
        assert obj.__dict__[regular_func.__name__] == 42
