# file: flutils.decorators.py:57-59
# asked: {"lines": [57, 58, 59], "branches": []}
# gained: {"lines": [57, 58, 59], "branches": []}

import pytest
from flutils.decorators import cached_property

def test_cached_property_init():
    def sample_func():
        """This is a sample function."""
        return 42

    # Create an instance of cached_property
    cached_prop = cached_property(sample_func)

    # Assert that the __doc__ attribute is set correctly
    assert cached_prop.__doc__ == "This is a sample function."
    # Assert that the func attribute is set correctly
    assert cached_prop.func == sample_func

def test_cached_property_with_monkeypatch():
    def sample_func():
        """This is another sample function."""
        return 100

    # Create an instance of cached_property
    cached_prop = cached_property(sample_func)

    # Assert that the __doc__ attribute is initially correct
    assert cached_prop.__doc__ == "This is another sample function."

    # Use monkeypatch to change the function's docstring
    def modified_func():
        """Modified docstring."""
        return 200

    # Update the cached_property's func to the modified function
    cached_prop.func = modified_func

    # Assert that the __doc__ attribute remains unchanged
    assert cached_prop.__doc__ == "This is another sample function."
    # Assert that the func attribute is now the modified function
    assert cached_prop.func.__doc__ == "Modified docstring."
