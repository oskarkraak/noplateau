# file: flutils.decorators.py:61-69
# asked: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}
# gained: {"lines": [61, 62, 65, 66, 68, 69], "branches": [[62, 65], [65, 66], [65, 68]]}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    @pytest.fixture
    def mock_obj(self, monkeypatch):
        class MockClass:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        return MockClass()

    def test_cached_property_value(self, mock_obj):
        assert mock_obj.y == 6  # Test the cached property value

    def test_cached_property_caching(self, mock_obj):
        # Access the property to cache the value
        value_first_access = mock_obj.y
        # Modify the underlying value
        mock_obj.x = 10
        # Access the property again
        value_second_access = mock_obj.y
        # Assert that the cached value is returned, not the recalculated one
        assert value_first_access == value_second_access

    def test_cached_property_with_coroutine(self, monkeypatch):
        async def async_func(self):
            await asyncio.sleep(0.1)
            return self.x + 1

        class MockAsyncClass:
            def __init__(self):
                self.x = 5

            @cached_property
            async def y(self):
                return await async_func(self)

        mock_async_obj = MockAsyncClass()
        result = asyncio.run(mock_async_obj.y)
        assert result == 6  # Test the async cached property value
