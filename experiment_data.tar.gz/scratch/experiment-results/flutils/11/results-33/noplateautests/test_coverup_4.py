# file: flutils.decorators.py:61-69
# asked: {"lines": [63], "branches": [[62, 63]]}
# gained: {"lines": [63], "branches": [[62, 63]]}

import pytest
from flutils.decorators import cached_property

class TestCachedProperty:
    def test_get_with_none_obj(self):
        """Test that __get__ returns self when obj is None."""
        prop = cached_property(lambda self: "value")
        result = prop.__get__(None, None)
        assert result is prop

    def test_get_with_coroutine_function(self, monkeypatch):
        """Test that __get__ calls _wrap_in_coroutine when func is a coroutine."""
        async def mock_coroutine(self):
            return "coroutine value"

        prop = cached_property(mock_coroutine)
        monkeypatch.setattr(prop, '_wrap_in_coroutine', lambda obj: "wrapped coroutine")
        
        result = prop.__get__(object(), None)
        assert result == "wrapped coroutine"

    def test_get_with_regular_function(self):
        """Test that __get__ calls the function and caches the result."""
        class TestClass:
            @cached_property
            def value(self):
                return "cached value"

        obj = TestClass()
        result = obj.value  # This should call the function and cache the result
        assert result == "cached value"
        assert obj.__dict__['value'] == "cached value"  # Check that the value is cached
