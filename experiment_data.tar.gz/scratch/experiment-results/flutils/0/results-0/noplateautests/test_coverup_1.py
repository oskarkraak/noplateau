# file: flutils.decorators.py:71-79
# asked: {"lines": [71, 73, 74, 75, 76, 77, 79], "branches": []}
# gained: {"lines": [71], "branches": []}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    @pytest.fixture
    def mock_obj(self, monkeypatch):
        class MockObj:
            pass
        return MockObj()

    @pytest.mark.asyncio
    async def test_wrap_in_coroutine(self, mock_obj):
        async def mock_func(obj):
            return "result"

        cp = cached_property()
        cp.func = mock_func
        
        # Call the _wrap_in_coroutine method
        wrapper = cp._wrap_in_coroutine(mock_obj)
        
        # Ensure the future is set in the object's __dict__
        result = await wrapper
        
        assert result == "result"
        assert mock_obj.__dict__[mock_func.__name__] is not None
        assert isinstance(mock_obj.__dict__[mock_func.__name__], asyncio.Future)
