# file: flutils.decorators.py:57-59
# asked: {"lines": [57, 58, 59], "branches": []}
# gained: {"lines": [57, 58, 59], "branches": []}

import pytest
from flutils.decorators import cached_property

def test_cached_property_init():
    def sample_func():
        """This is a sample function."""
        return 42

    # Create an instance of cached_property
    cached_prop = cached_property(sample_func)

    # Assert that the __doc__ attribute is set correctly
    assert cached_prop.__doc__ == "This is a sample function."
    # Assert that the func attribute is set correctly
    assert cached_prop.func == sample_func

def test_cached_property_with_monkeypatch():
    def sample_func():
        """This is another sample function."""
        return 100

    # Create an instance of cached_property
    cached_prop = cached_property(sample_func)

    # Assert that the __doc__ attribute is initially correct
    assert cached_prop.__doc__ == "This is another sample function."

    # Use monkeypatch to change the function's __doc__ attribute
    sample_func.__doc__ = "Modified docstring."

    # Recreate the cached_property to reflect the change
    cached_prop = cached_property(sample_func)

    # Assert that the __doc__ attribute is updated
    assert cached_prop.__doc__ == "Modified docstring."
