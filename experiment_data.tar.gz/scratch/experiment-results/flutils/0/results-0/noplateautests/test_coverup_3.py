# file: flutils.decorators.py:61-69
# asked: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}
# gained: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}

import asyncio
import pytest
from flutils.decorators import cached_property

class TestCachedProperty:
    @pytest.fixture
    def mock_obj(self, monkeypatch):
        class MockObj:
            @cached_property
            def value(self):
                return 42

        return MockObj()

    def test_get_with_none_obj(self):
        prop = cached_property(lambda self: 42)
        assert prop.__get__(None, None) is prop

    def test_get_with_coroutine_function(self, monkeypatch):
        async def async_func(self):
            return 42

        prop = cached_property(async_func)
        monkeypatch.setattr(async_func, '__name__', 'async_func')

        result = prop.__get__(self.mock_obj, None)
        assert asyncio.iscoroutinefunction(async_func)
        assert asyncio.run(result) == 42

    def test_get_with_regular_function(self, mock_obj):
        result = mock_obj.value
        assert result == 42
        assert 'value' in mock_obj.__dict__
        assert mock_obj.__dict__['value'] == 42
