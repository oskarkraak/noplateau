# file: flutils.decorators.py:61-69
# asked: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}
# gained: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    def test_get_with_none_obj(self):
        prop = cached_property(lambda self: 42)
        assert prop.__get__(None, None) is prop

    def test_get_with_coroutine_function(self):
        async def async_func(self):
            return 42

        prop = cached_property(async_func)

        class TestClass:
            async def func(self):
                return await async_func(self)

        obj = TestClass()
        result = prop.__get__(obj, TestClass)
        assert asyncio.iscoroutine(result)
        assert asyncio.run(result) == 42

    def test_get_with_regular_function(self):
        def regular_func(self):
            return 42

        prop = cached_property(regular_func)

        class TestClass:
            pass

        obj = TestClass()
        result = prop.__get__(obj, TestClass)
        assert result == 42
        assert obj.__dict__[regular_func.__name__] == 42
