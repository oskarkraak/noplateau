# file: flutils.decorators.py:61-69
# asked: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}
# gained: {"lines": [61, 62, 65, 66, 68, 69], "branches": [[62, 65], [65, 66], [65, 68]]}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    @pytest.fixture
    def setup_class(self, monkeypatch):
        class MyClass:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        return MyClass()

    def test_cached_property_value(self, setup_class):
        obj = setup_class
        assert obj.y == 6  # Test the cached property value

    def test_cached_property_caching(self, setup_class):
        obj = setup_class
        _ = obj.y  # Access the property to cache it
        assert 'y' in obj.__dict__  # Ensure the property is cached
        assert obj.y == 6  # Accessing again should not recompute

    def test_cached_property_with_coroutine(self, monkeypatch):
        async def async_func(self):
            await asyncio.sleep(0.1)
            return self.x + 1

        class MyAsyncClass:
            def __init__(self):
                self.x = 5

            @cached_property
            async def y(self):
                return await async_func(self)

        obj = MyAsyncClass()
        result = asyncio.run(obj.y)  # Test the coroutine cached property
        assert result == 6  # Verify the result of the coroutine
