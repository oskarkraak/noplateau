# file: flutils.decorators.py:61-69
# asked: {"lines": [63], "branches": [[62, 63]]}
# gained: {"lines": [63], "branches": [[62, 63]]}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    def test_cached_property_without_obj(self):
        """Test that cached_property returns itself when accessed without an instance."""
        prop = cached_property(lambda self: 42)
        assert prop is prop  # Ensure it returns itself

    def test_cached_property_with_obj(self):
        """Test that cached_property computes the value when accessed with an instance."""
        class MyClass:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        assert obj.y == 6  # Ensure the cached property computes correctly

    def test_cached_property_caching(self):
        """Test that cached_property caches the value after first access."""
        class MyClass:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        assert obj.y == 6  # First access, should compute
        obj.x = 10  # Change the underlying value
        assert obj.y == 6  # Should still return the cached value

    def test_cached_property_reset(self):
        """Test that deleting the cached property resets it."""
        class MyClass:
            def __init__(self):
                self.x = 5

            @cached_property
            def y(self):
                return self.x + 1

        obj = MyClass()
        assert obj.y == 6  # First access, should compute
        del obj.y  # Reset the cached property
        obj.x = 10  # Change the underlying value
        assert obj.y == 11  # Should compute again with the new value

    def test_cached_property_with_none_obj(self):
        """Test that cached_property returns itself when accessed with None as the object."""
        prop = cached_property(lambda self: 42)
        assert prop.__get__(None, None) is prop  # Ensure it returns itself when obj is None

    @pytest.mark.asyncio
    async def test_cached_property_with_coroutine(self):
        """Test that cached_property works with coroutine functions."""
        class MyClass:
            def __init__(self):
                self.x = 5

            @cached_property
            async def y(self):
                await asyncio.sleep(0.1)  # Simulate async work
                return self.x + 1

        obj = MyClass()
        result = await obj.y  # Access the coroutine property
        assert result == 6  # Ensure the cached property computes correctly
