# file: flutils.decorators.py:61-69
# asked: {"lines": [63, 66], "branches": [[62, 63], [65, 66]]}
# gained: {"lines": [63], "branches": [[62, 63]]}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    def test_cached_property_non_coroutine(self):
        class MyClass:
            def __init__(self):
                self.value = 10

            @cached_property
            def computed_value(self):
                return self.value + 5

        obj = MyClass()
        assert obj.computed_value == 15
        assert 'computed_value' in obj.__dict__

    @pytest.mark.asyncio
    async def test_cached_property_coroutine(self):
        class MyClass:
            def __init__(self):
                self.value = 10

            @cached_property
            async def async_computed_value(self):
                return self.value + 5

        obj = MyClass()
        result = await obj.async_computed_value
        assert result == 15
        assert 'async_computed_value' in obj.__dict__

    def test_cached_property_with_none_obj(self):
        prop = cached_property(lambda self: 42)
        assert prop.__get__(None, None) is prop

    @pytest.mark.asyncio
    async def test_cached_property_coroutine_with_none_obj(self):
        prop = cached_property(lambda self: 42)
        result = await prop.__get__(None, None)
        assert result is prop
