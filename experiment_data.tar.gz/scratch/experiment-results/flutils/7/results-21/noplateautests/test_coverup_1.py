# file: flutils.decorators.py:57-59
# asked: {"lines": [57, 58, 59], "branches": []}
# gained: {"lines": [57, 58, 59], "branches": []}

import pytest
from flutils.decorators import cached_property

def test_cached_property_init_with_docstring():
    def sample_function():
        """This is a sample function."""
        return 42

    cached_prop = cached_property(sample_function)
    assert cached_prop.__doc__ == "This is a sample function."
    assert cached_prop.func == sample_function

def test_cached_property_init_without_docstring():
    def sample_function():
        return 42

    cached_prop = cached_property(sample_function)
    assert cached_prop.__doc__ is None
    assert cached_prop.func == sample_function
