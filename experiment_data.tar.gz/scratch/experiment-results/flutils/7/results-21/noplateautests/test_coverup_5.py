# file: flutils.decorators.py:61-69
# asked: {"lines": [66], "branches": [[65, 66]]}
# gained: {"lines": [66], "branches": [[65, 66]]}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    class TestClass:
        @cached_property
        async def async_property(self):
            return "coroutine result"

        @cached_property
        def sync_property(self):
            return "sync result"

    def test_async_cached_property(self):
        obj = self.TestClass()
        result = asyncio.run(obj.async_property)
        assert result == "coroutine result"

    def test_sync_cached_property(self):
        obj = self.TestClass()
        result = obj.sync_property
        assert result == "sync result"
