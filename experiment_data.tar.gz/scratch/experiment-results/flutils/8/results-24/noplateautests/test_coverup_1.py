# file: flutils.decorators.py:57-59
# asked: {"lines": [57, 58, 59], "branches": []}
# gained: {"lines": [57, 58, 59], "branches": []}

import pytest
from flutils.decorators import cached_property

def test_cached_property_init():
    def sample_function():
        """This is a sample function."""
        return 42

    # Create an instance of cached_property
    cached_prop = cached_property(sample_function)

    # Assert that the __doc__ attribute is set correctly
    assert cached_prop.__doc__ == "This is a sample function."
    # Assert that the func attribute is set correctly
    assert cached_prop.func == sample_function

def test_cached_property_with_docstring():
    def another_function():
        """Another function's docstring."""
        return "Hello, World!"

    cached_prop = cached_property(another_function)

    # Assert that the __doc__ attribute is set correctly
    assert cached_prop.__doc__ == "Another function's docstring."
    assert cached_prop.func == another_function
