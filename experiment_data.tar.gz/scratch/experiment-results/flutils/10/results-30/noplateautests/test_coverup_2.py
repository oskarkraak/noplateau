# file: flutils.decorators.py:61-69
# asked: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}
# gained: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    
    def test_get_with_none_obj(self):
        """Test __get__ method when obj is None."""
        prop = cached_property(lambda self: 42)
        assert prop.__get__(None, None) is prop

    def test_get_with_coroutine_function(self, monkeypatch):
        """Test __get__ method when the function is a coroutine."""
        async def async_func(self):
            return 42
        
        prop = cached_property(async_func)
        
        # Mock the _wrap_in_coroutine method to return a specific value
        async def mock_wrap_in_coroutine(obj):
            return 42
        
        monkeypatch.setattr(prop, '_wrap_in_coroutine', mock_wrap_in_coroutine)
        
        result = asyncio.run(prop.__get__(object(), None))
        assert result == 42

    def test_get_with_normal_function(self):
        """Test __get__ method when the function is a normal function."""
        class TestObject:
            pass
        
        def normal_func(self):
            return 42
        
        prop = cached_property(normal_func)
        obj = TestObject()
        
        result = prop.__get__(obj, None)
        assert result == 42
        assert obj.__dict__[normal_func.__name__] == 42
