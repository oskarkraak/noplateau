# file: flutils.decorators.py:61-69
# asked: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}
# gained: {"lines": [61, 62, 63, 65, 66, 68, 69], "branches": [[62, 63], [62, 65], [65, 66], [65, 68]]}

import pytest
import asyncio
from flutils.decorators import cached_property

class TestCachedProperty:
    class TestClass:
        def __init__(self):
            self.x = 5

        @cached_property
        def y(self):
            return self.x + 1

    class TestCoroutineClass:
        def __init__(self):
            self.x = 5

        @cached_property
        async def y(self):
            await asyncio.sleep(0.1)
            return self.x + 1

    def test_cached_property_value(self):
        obj = self.TestClass()
        assert obj.y == 6
        assert 'y' in obj.__dict__

    def test_cached_property_coroutine(self, monkeypatch):
        obj = self.TestCoroutineClass()

        async def run_test():
            value = await obj.y
            assert value == 6
            assert 'y' in obj.__dict__

        asyncio.run(run_test())

    def test_cached_property_no_obj(self):
        prop = cached_property(lambda self: 42)
        assert prop.__get__(None, None) is prop
