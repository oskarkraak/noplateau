# file: pymonet.semigroups.py:84-99
# asked: {"lines": [84, 85, 89, 90, 92, 99], "branches": []}
# gained: {"lines": [84, 85, 89, 90, 92, 99], "branches": []}

import pytest
from pymonet.semigroups import First, Semigroup

@pytest.fixture
def first_instance():
    return First(10)

@pytest.fixture
def second_instance():
    return First(20)

def test_first_str(first_instance):
    assert str(first_instance) == 'Fist[value=10]'

def test_first_concat(first_instance, second_instance):
    result = first_instance.concat(second_instance)
    assert isinstance(result, First)
    assert result.value == 10  # Should return the first value
