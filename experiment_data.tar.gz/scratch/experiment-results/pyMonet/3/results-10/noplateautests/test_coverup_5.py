# file: pymonet.semigroups.py:64-81
# asked: {"lines": [64, 65, 69, 71, 72, 74, 81], "branches": []}
# gained: {"lines": [64, 65, 69, 71, 72, 74, 81], "branches": []}

import pytest
from pymonet.semigroups import One

def test_one_str():
    one_instance = One(True)
    assert str(one_instance) == 'One[value=True]'

def test_one_concat_with_true_value():
    one_instance_a = One(True)
    one_instance_b = One(False)
    result = one_instance_a.concat(one_instance_b)
    assert result.value is True

def test_one_concat_with_false_value():
    one_instance_a = One(False)
    one_instance_b = One(False)
    result = one_instance_a.concat(one_instance_b)
    assert result.value is False

def test_one_concat_with_none_value():
    one_instance_a = One(None)
    one_instance_b = One(True)
    result = one_instance_a.concat(one_instance_b)
    assert result.value is True

def test_one_concat_with_both_none():
    one_instance_a = One(None)
    one_instance_b = One(None)
    result = one_instance_a.concat(one_instance_b)
    assert result.value is None
