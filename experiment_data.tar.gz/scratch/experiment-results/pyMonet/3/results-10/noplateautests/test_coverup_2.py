# file: pymonet.semigroups.py:44-61
# asked: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}
# gained: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}

import pytest
from pymonet.semigroups import All

@pytest.fixture
def all_instance_true():
    return All(True)

@pytest.fixture
def all_instance_false():
    return All(False)

def test_concat_with_true_values(all_instance_true):
    other = All(True)
    result = all_instance_true.concat(other)
    assert result.value is True
    assert str(result) == 'All[value=True]'

def test_concat_with_true_and_false(all_instance_true, all_instance_false):
    result = all_instance_true.concat(all_instance_false)
    assert result.value is False
    assert str(result) == 'All[value=False]'

def test_concat_with_false_values(all_instance_false):
    other = All(False)
    result = all_instance_false.concat(other)
    assert result.value is False
    assert str(result) == 'All[value=False]'
