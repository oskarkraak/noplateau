# file: pymonet.semigroups.py:160-177
# asked: {"lines": [160, 161, 165, 167, 168, 170, 177], "branches": []}
# gained: {"lines": [160, 161, 165, 167, 168, 170, 177], "branches": []}

import pytest
from pymonet.semigroups import Min

def test_min_str():
    min_instance = Min(5)
    assert str(min_instance) == 'Min[value=5]'

def test_min_concat_with_smaller_value():
    min1 = Min(3)
    min2 = Min(5)
    result = min1.concat(min2)
    assert result.value == 3

def test_min_concat_with_larger_value():
    min1 = Min(7)
    min2 = Min(2)
    result = min1.concat(min2)
    assert result.value == 2

def test_min_concat_with_equal_value():
    min1 = Min(4)
    min2 = Min(4)
    result = min1.concat(min2)
    assert result.value == 4
