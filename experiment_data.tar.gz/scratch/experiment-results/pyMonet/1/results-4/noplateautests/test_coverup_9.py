# file: pymonet.semigroups.py:120-137
# asked: {"lines": [126, 135, 136], "branches": []}
# gained: {"lines": [126, 135, 136], "branches": []}

import pytest
from pymonet.semigroups import Map

def test_map_str():
    map_instance = Map(value={})
    assert str(map_instance) == 'Map[value={}]'

def test_map_concat():
    map1 = Map(value={'a': Map(value={}), 'b': Map(value={})})
    map2 = Map(value={'a': Map(value={}), 'b': Map(value={})})
    
    result = map1.concat(map2)
    
    assert isinstance(result, Map)
    assert len(result.value) == 2
    assert 'a' in result.value
    assert 'b' in result.value
