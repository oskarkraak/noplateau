# file: pymonet.semigroups.py:140-157
# asked: {"lines": [140, 141, 145, 147, 148, 150, 157], "branches": []}
# gained: {"lines": [140, 141, 145, 147, 148, 150, 157], "branches": []}

import pytest
from pymonet.semigroups import Max

@pytest.fixture
def max_instance_a():
    return Max(3)

@pytest.fixture
def max_instance_b():
    return Max(5)

def test_max_str(max_instance_a):
    assert str(max_instance_a) == 'Max[value=3]'

def test_max_concat_a_greater(max_instance_a, max_instance_b):
    result = max_instance_a.concat(max_instance_b)
    assert result.value == 5
    assert isinstance(result, Max)

def test_max_concat_b_greater(max_instance_a, max_instance_b):
    result = max_instance_b.concat(max_instance_a)
    assert result.value == 5
    assert isinstance(result, Max)

def test_max_concat_equal(max_instance_a):
    equal_instance = Max(3)
    result = max_instance_a.concat(equal_instance)
    assert result.value == 3
    assert isinstance(result, Max)
