import pytest
from pymonet.semigroups import Last, Min, Sum, Max, All, One, Semigroup

# Tests for Last
def test_last_str_edge_cases():
    assert str(Last(None)) == 'Last[value=None]'
    assert str(Last(float('inf'))) == 'Last[value=inf]'
    assert str(Last(float('-inf'))) == 'Last[value=-inf]'

# Tests for Min
def test_min_str_edge_cases():
    assert str(Min(None)) == 'Min[value=None]'
    assert str(Min(float('inf'))) == 'Min[value=inf]'
    assert str(Min(float('-inf'))) == 'Min[value=-inf]'

# Tests for Sum
def test_sum_str_edge_cases():
    assert str(Sum(None)) == 'Sum[value=None]'
    assert str(Sum(float('inf'))) == 'Sum[value=inf]'
    assert str(Sum(float('-inf'))) == 'Sum[value=-inf]'

# Tests for Max
def test_max_str_edge_cases():
    assert str(Max(None)) == 'Max[value=None]'
    assert str(Max(float('inf'))) == 'Max[value=inf]'
    assert str(Max(float('-inf'))) == 'Max[value=-inf]'

# Tests for All
def test_all_str_edge_cases():
    assert str(All(None)) == 'All[value=None]'

def test_all_concat_edge_cases():
    assert All(True).concat(All(None)).value is None
    assert All(False).concat(All(True)).value is False
    assert All(True).concat(All(False)).value is False
    assert All(None).concat(All(None)).value is None

# Tests for One
def test_one_str_edge_cases():
    assert str(One(None)) == 'One[value=None]'

# Tests for Semigroup
def test_semigroup_init_edge_cases():
    assert Semigroup(None).value is None
    assert Semigroup(float('inf')).value == float('inf')
    assert Semigroup(float('-inf')).value == float('-inf')

def test_semigroup_eq_edge_cases():
    assert Semigroup(None) == Semigroup(None)
    assert Semigroup(float('inf')) == Semigroup(float('inf'))
    assert Semigroup(float('-inf')) == Semigroup(float('-inf'))

def test_semigroup_fold_edge_cases():
    assert Semigroup(None).fold(lambda x: x) is None
    assert Semigroup(float('inf')).fold(lambda x: x) == float('inf')
    assert Semigroup(float('-inf')).fold(lambda x: x) == float('-inf')

def test_semigroup_neutral_edge_cases():
    Semigroup.neutral_element = None
    assert Semigroup.neutral().value is None
