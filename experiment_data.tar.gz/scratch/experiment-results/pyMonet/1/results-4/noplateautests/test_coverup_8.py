# file: pymonet.semigroups.py:84-99
# asked: {"lines": [90, 99], "branches": []}
# gained: {"lines": [90, 99], "branches": []}

import pytest
from pymonet.semigroups import First

def test_first_str():
    first_instance = First(value=10)
    assert str(first_instance) == 'Fist[value=10]'

def test_first_concat():
    first_instance_1 = First(value=10)
    first_instance_2 = First(value=20)
    result = first_instance_1.concat(first_instance_2)
    assert isinstance(result, First)
    assert result.value == 10
