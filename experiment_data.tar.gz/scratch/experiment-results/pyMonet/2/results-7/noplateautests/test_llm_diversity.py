import pytest
from pymonet.semigroups import Sum, First, Semigroup, Min, One, All, Max, Last

# Tests for Sum
@pytest.fixture
def sum_instance():
    return Sum(5)

@pytest.fixture
def another_sum_instance():
    return Sum(10)

def test_sum_str(sum_instance):
    assert str(sum_instance) == 'Sum[value=5]'

def test_sum_concat(another_sum_instance):
    sum_instance = Sum(5)
    result = sum_instance.concat(another_sum_instance)
    assert result.value == 15
    assert isinstance(result, Sum)

def test_sum_concat_with_zero(sum_instance):
    zero_sum = Sum(0)
    result = sum_instance.concat(zero_sum)
    assert result.value == 5
    assert isinstance(result, Sum)

def test_sum_concat_negative(sum_instance):
    negative_sum = Sum(-3)
    result = sum_instance.concat(negative_sum)
    assert result.value == 2
    assert isinstance(result, Sum)

def test_sum_concat_with_large_numbers():
    large_sum1 = Sum(1e10)
    large_sum2 = Sum(1e10)
    result = large_sum1.concat(large_sum2)
    assert result.value == 2e10
    assert isinstance(result, Sum)

# Tests for First
def test_first_concat():
    first_instance1 = First(10)
    first_instance2 = First(20)
    result = first_instance1.concat(first_instance2)
    assert isinstance(result, First)
    assert result.value == 10

def test_first_concat_with_none():
    first_instance = First(None)
    result = first_instance.concat(First(20))
    assert result.value is None

# Tests for Semigroup
def test_semigroup_init():
    semigroup = Semigroup(5)
    assert semigroup.value == 5

def test_semigroup_eq():
    semigroup1 = Semigroup(5)
    semigroup2 = Semigroup(5)
    semigroup3 = Semigroup(10)
    assert semigroup1 == semigroup2
    assert semigroup1 != semigroup3

def test_semigroup_fold():
    semigroup = Semigroup(5)
    result = semigroup.fold(lambda x: x * 2)
    assert result == 10

def test_semigroup_neutral():
    class TestSemigroup(Semigroup):
        neutral_element = 0

    neutral_semigroup = TestSemigroup.neutral()
    assert neutral_semigroup.value == 0

# Tests for Min
@pytest.fixture
def min_instance_a():
    return Min(5)

@pytest.fixture
def min_instance_b():
    return Min(10)

@pytest.fixture
def min_instance_c():
    return Min(float('inf'))

def test_min_str(min_instance_a):
    assert str(min_instance_a) == 'Min[value=5]'

def test_min_concat_with_smaller_value(min_instance_a, min_instance_b):
    result = min_instance_a.concat(min_instance_b)
    assert result.value == 5
    assert isinstance(result, Min)

def test_min_concat_with_larger_value(min_instance_b, min_instance_a):
    result = min_instance_b.concat(min_instance_a)
    assert result.value == 5
    assert isinstance(result, Min)

def test_min_concat_with_neutral_element(min_instance_a, min_instance_c):
    result = min_instance_a.concat(min_instance_c)
    assert result.value == 5
    assert isinstance(result, Min)

def test_min_concat_with_equal_value(min_instance_a):
    result = min_instance_a.concat(Min(5))
    assert result.value == 5
    assert isinstance(result, Min)

# Tests for One
def test_one_str():
    one_instance = One(True)
    assert str(one_instance) == 'One[value=True]'

def test_one_concat_with_true_value():
    one_instance_a = One(True)
    one_instance_b = One(False)
    result = one_instance_a.concat(one_instance_b)
    assert result.value is True

def test_one_concat_with_false_value():
    one_instance_a = One(False)
    one_instance_b = One(False)
    result = one_instance_a.concat(one_instance_b)
    assert result.value is False

def test_one_concat_with_true_and_false():
    one_instance_a = One(False)
    one_instance_b = One(True)
    result = one_instance_a.concat(one_instance_b)
    assert result.value is True

# Tests for All
def test_all_str():
    instance = All(True)
    assert str(instance) == 'All[value=True]'
    
    instance_false = All(False)
    assert str(instance_false) == 'All[value=False]'

def test_all_concat():
    a = All(True)
    b = All(True)
    c = All(False)

    result = a.concat(b)
    assert result.value is True
    assert isinstance(result, All)

    result = a.concat(c)
    assert result.value is False
    assert isinstance(result, All)

    result = c.concat(b)
    assert result.value is False
    assert isinstance(result, All)

    result = c.concat(c)
    assert result.value is False
    assert isinstance(result, All)

    result = a.concat(All(True))
    assert result.value is True
    assert isinstance(result, All)

    result = a.concat(All(False))
    assert result.value is False
    assert isinstance(result, All)

# Tests for Max
def test_max_concat_with_smaller_value():
    max1 = Max(5)
    max2 = Max(3)
    result = max1.concat(max2)
    assert result.value == 5
    assert str(result) == 'Max[value=5]'

def test_max_concat_with_larger_value():
    max1 = Max(2)
    max2 = Max(8)
    result = max1.concat(max2)
    assert result.value == 8
    assert str(result) == 'Max[value=8]'

def test_max_concat_with_equal_value():
    max1 = Max(4)
    max2 = Max(4)
    result = max1.concat(max2)
    assert result.value == 4
    assert str(result) == 'Max[value=4]'

def test_max_concat_with_neutral_element():
    max1 = Max(10)
    max2 = Max(Max.neutral_element)
    result = max1.concat(max2)
    assert result.value == 10
    assert str(result) == 'Max[value=10]'

# Tests for Last
def test_last_str():
    last_instance = Last(5)
    assert str(last_instance) == 'Last[value=5]'

def test_last_concat():
    last1 = Last(10)
    last2 = Last(20)
    result = last1.concat(last2)
    assert result.value == 20
    assert isinstance(result, Last)

def test_last_concat_with_mock():
    last1 = Last(15)
    class MockLast:
        def __init__(self, value):
            self.value = value

    mock_last_instance = MockLast(25)
    result = last1.concat(mock_last_instance)
    assert result.value == 25
    assert isinstance(result, Last)

def test_last_concat_with_none():
    last_instance = Last(10)
    result = last_instance.concat(Last(None))
    assert result.value is None
