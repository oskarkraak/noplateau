# file: pymonet.semigroups.py:24-41
# asked: {"lines": [24, 25, 29, 31, 32, 34, 41], "branches": []}
# gained: {"lines": [24, 25, 29, 31, 32, 34, 41], "branches": []}

import pytest
from pymonet.semigroups import Sum

@pytest.fixture
def sum_instance():
    return Sum(5)

@pytest.fixture
def another_sum_instance():
    return Sum(10)

def test_sum_str(sum_instance):
    assert str(sum_instance) == 'Sum[value=5]'

def test_sum_concat(sum_instance, another_sum_instance):
    result = sum_instance.concat(another_sum_instance)
    assert result.value == 15
    assert isinstance(result, Sum)

def test_sum_concat_with_zero(sum_instance):
    zero_sum = Sum(0)
    result = sum_instance.concat(zero_sum)
    assert result.value == 5
    assert isinstance(result, Sum)

def test_sum_concat_negative(sum_instance):
    negative_sum = Sum(-3)
    result = sum_instance.concat(negative_sum)
    assert result.value == 2
    assert isinstance(result, Sum)
