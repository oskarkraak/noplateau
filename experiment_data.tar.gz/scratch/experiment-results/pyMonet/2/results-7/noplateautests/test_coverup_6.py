# file: pymonet.semigroups.py:44-61
# asked: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}
# gained: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}

import pytest
from pymonet.semigroups import All

def test_all_str():
    instance = All(True)
    assert str(instance) == 'All[value=True]'
    
    instance_false = All(False)
    assert str(instance_false) == 'All[value=False]'

def test_all_concat():
    a = All(True)
    b = All(True)
    c = All(False)

    result = a.concat(b)
    assert result.value is True
    assert isinstance(result, All)

    result = a.concat(c)
    assert result.value is False
    assert isinstance(result, All)

    result = c.concat(b)
    assert result.value is False
    assert isinstance(result, All)

    result = c.concat(c)
    assert result.value is False
    assert isinstance(result, All)

    result = a.concat(All(True))
    assert result.value is True
    assert isinstance(result, All)

    result = a.concat(All(False))
    assert result.value is False
    assert isinstance(result, All)
