# file: pymonet.semigroups.py:102-117
# asked: {"lines": [102, 103, 107, 108, 110, 117], "branches": []}
# gained: {"lines": [102, 103, 107, 108, 110, 117], "branches": []}

import pytest
from pymonet.semigroups import Last

def test_last_str():
    last_instance = Last(5)
    assert str(last_instance) == 'Last[value=5]'

def test_last_concat():
    last1 = Last(10)
    last2 = Last(20)
    result = last1.concat(last2)
    assert result.value == 20
    assert isinstance(result, Last)

def test_last_concat_with_mock():
    last1 = Last(15)
    class MockLast:
        def __init__(self, value):
            self.value = value

    mock_last_instance = MockLast(25)
    result = last1.concat(mock_last_instance)
    assert result.value == 25
    assert isinstance(result, Last)
