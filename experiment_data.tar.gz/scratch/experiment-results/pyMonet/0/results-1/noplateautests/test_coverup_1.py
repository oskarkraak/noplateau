# file: pymonet.semigroups.py:102-117
# asked: {"lines": [102, 103, 107, 108, 110, 117], "branches": []}
# gained: {"lines": [102, 103, 107, 108, 110, 117], "branches": []}

import pytest
from pymonet.semigroups import Last

def test_last_str():
    last_instance = Last(5)
    assert str(last_instance) == 'Last[value=5]'

def test_last_concat():
    last_instance1 = Last(10)
    last_instance2 = Last(20)
    result = last_instance1.concat(last_instance2)
    assert result.value == 20
    assert isinstance(result, Last)

def test_last_concat_with_same_value():
    last_instance1 = Last(15)
    last_instance2 = Last(15)
    result = last_instance1.concat(last_instance2)
    assert result.value == 15
    assert isinstance(result, Last)
