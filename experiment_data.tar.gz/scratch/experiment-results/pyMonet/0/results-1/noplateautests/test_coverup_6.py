# file: pymonet.semigroups.py:140-157
# asked: {"lines": [140, 141, 145, 147, 148, 150, 157], "branches": []}
# gained: {"lines": [140, 141, 145, 147, 148, 150, 157], "branches": []}

import pytest
from pymonet.semigroups import Max

def test_max_concat_with_smaller_value():
    max1 = Max(5)
    max2 = Max(3)
    result = max1.concat(max2)
    assert result.value == 5
    assert str(result) == 'Max[value=5]'

def test_max_concat_with_larger_value():
    max1 = Max(2)
    max2 = Max(8)
    result = max1.concat(max2)
    assert result.value == 8
    assert str(result) == 'Max[value=8]'

def test_max_concat_with_equal_value():
    max1 = Max(4)
    max2 = Max(4)
    result = max1.concat(max2)
    assert result.value == 4
    assert str(result) == 'Max[value=4]'

def test_max_concat_with_neutral_element():
    max1 = Max(10)
    max2 = Max(Max.neutral_element)
    result = max1.concat(max2)
    assert result.value == 10
    assert str(result) == 'Max[value=10]'
