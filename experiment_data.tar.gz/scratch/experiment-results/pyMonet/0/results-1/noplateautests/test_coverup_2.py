# file: pymonet.semigroups.py:24-41
# asked: {"lines": [24, 25, 29, 31, 32, 34, 41], "branches": []}
# gained: {"lines": [24, 25, 29, 31, 32, 34, 41], "branches": []}

import pytest
from pymonet.semigroups import Sum

@pytest.fixture
def sum_instance():
    return Sum(5)

def test_sum_str(sum_instance):
    assert str(sum_instance) == 'Sum[value=5]'

def test_sum_concat():
    sum_a = Sum(3)
    sum_b = Sum(7)
    result = sum_a.concat(sum_b)
    assert result.value == 10
    assert isinstance(result, Sum)

def test_sum_concat_with_zero():
    sum_a = Sum(0)
    sum_b = Sum(0)
    result = sum_a.concat(sum_b)
    assert result.value == 0
    assert isinstance(result, Sum)

def test_sum_concat_negative():
    sum_a = Sum(-2)
    sum_b = Sum(-3)
    result = sum_a.concat(sum_b)
    assert result.value == -5
    assert isinstance(result, Sum)
