# file: pymonet.semigroups.py:64-81
# asked: {"lines": [64, 65, 69, 71, 72, 74, 81], "branches": []}
# gained: {"lines": [64, 65, 69, 71, 72, 74, 81], "branches": []}

import pytest
from pymonet.semigroups import One

@pytest.fixture
def one_instance():
    return One(True)

@pytest.fixture
def another_one_instance():
    return One(False)

def test_one_str(one_instance):
    assert str(one_instance) == 'One[value=True]'

def test_one_concat_with_true_value(one_instance, another_one_instance):
    result = one_instance.concat(another_one_instance)
    assert result.value is True
    assert isinstance(result, One)

def test_one_concat_with_false_value(one_instance):
    another_instance = One(False)
    result = one_instance.concat(another_instance)
    assert result.value is True
    assert isinstance(result, One)

def test_one_concat_with_another_true_value(one_instance):
    another_instance = One(True)
    result = one_instance.concat(another_instance)
    assert result.value is True
    assert isinstance(result, One)

def test_one_concat_with_both_false_values(another_one_instance):
    result = another_one_instance.concat(another_one_instance)
    assert result.value is False
    assert isinstance(result, One)
