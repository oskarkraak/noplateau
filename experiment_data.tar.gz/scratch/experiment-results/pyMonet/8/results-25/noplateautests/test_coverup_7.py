# file: pymonet.semigroups.py:140-157
# asked: {"lines": [140, 141, 145, 147, 148, 150, 157], "branches": []}
# gained: {"lines": [140, 141, 145, 147, 148, 150, 157], "branches": []}

import pytest
from pymonet.semigroups import Max

def test_max_concat_with_larger_value():
    max1 = Max(5)
    max2 = Max(10)
    result = max1.concat(max2)
    assert result.value == 10
    assert str(result) == 'Max[value=10]'

def test_max_concat_with_smaller_value():
    max1 = Max(15)
    max2 = Max(10)
    result = max1.concat(max2)
    assert result.value == 15
    assert str(result) == 'Max[value=15]'

def test_max_concat_with_equal_value():
    max1 = Max(20)
    max2 = Max(20)
    result = max1.concat(max2)
    assert result.value == 20
    assert str(result) == 'Max[value=20]'

def test_max_concat_with_neutral_element():
    max1 = Max(5)
    max2 = Max(Max.neutral_element)
    result = max1.concat(max2)
    assert result.value == 5
    assert str(result) == 'Max[value=5]'
