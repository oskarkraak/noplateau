# file: pymonet.semigroups.py:44-61
# asked: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}
# gained: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}

import pytest
from pymonet.semigroups import All

def test_all_str():
    instance = All(True)
    assert str(instance) == 'All[value=True]'
    
    instance_false = All(False)
    assert str(instance_false) == 'All[value=False]'

def test_all_concat():
    a = All(True)
    b = All(True)
    c = a.concat(b)
    assert c.value is True

    d = All(False)
    c = a.concat(d)
    assert c.value is False

    e = All(False)
    c = d.concat(e)
    assert c.value is False

    f = All(True)
    c = d.concat(f)
    assert c.value is False

    g = All(True)
    c = g.concat(f)
    assert c.value is True
