import pytest
from pymonet.semigroups import All, Min, Last, First, Semigroup, One, Max, Sum

# Tests for All
def test_all_str():
    assert str(All(True)) == 'All[value=True]'
    assert str(All(False)) == 'All[value=False]'

def test_all_concat():
    assert All(True).concat(All(True)).value is True
    assert All(True).concat(All(False)).value is False
    assert All(False).concat(All(True)).value is False
    assert All(False).concat(All(False)).value is False

# Tests for Min
def test_min_str():
    assert str(Min(5)) == 'Min[value=5]'

def test_min_concat():
    assert Min(3).concat(Min(5)).value == 3
    assert Min(7).concat(Min(2)).value == 2
    assert Min(4).concat(Min(4)).value == 4
    assert Min(-1).concat(Min(0)).value == -1  # Edge case with negative

# Tests for Last
def test_last_str():
    assert str(Last(5)) == 'Last[value=5]'

def test_last_concat():
    assert Last(3).concat(Last(7)).value == 7
    assert Last(10).concat(Last(10)).value == 10
    assert Last(0).concat(Last(-1)).value == -1  # Edge case with negative

# Tests for First
def test_first_str():
    assert str(First(10)) == 'Fist[value=10]'

def test_first_concat():
    assert First(10).concat(First(20)).value == 10
    assert First(5).concat(First(15)).value == 5
    assert First(0).concat(First(-1)).value == 0  # Edge case with negative

# Tests for Semigroup
def test_semigroup_init():
    assert Semigroup(5).value == 5

def test_semigroup_eq():
    assert Semigroup(5) == Semigroup(5)
    assert Semigroup(5) != Semigroup(10)

def test_semigroup_fold():
    assert Semigroup(5).fold(lambda x: x * 2) == 10

def test_semigroup_neutral():
    class TestSemigroup(Semigroup):
        neutral_element = 0
    assert TestSemigroup.neutral().value == 0

# Tests for One
def test_one_str():
    assert str(One(True)) == 'One[value=True]'

def test_one_concat():
    assert One(True).concat(One(False)).value is True
    assert One(False).concat(One(False)).value is False
    assert One(True).concat(One(True)).value is True

# Tests for Max
def test_max_concat():
    assert Max(5).concat(Max(10)).value == 10
    assert Max(15).concat(Max(10)).value == 15
    assert Max(20).concat(Max(20)).value == 20
    assert Max(5).concat(Max(Max.neutral_element)).value == 5  # Edge case with neutral

# Tests for Sum
def test_sum_str():
    assert str(Sum(5)) == 'Sum[value=5]'

def test_sum_concat():
    assert Sum(3).concat(Sum(7)).value == 10
    assert Sum(0).concat(Sum(0)).value == 0
    assert Sum(-5).concat(Sum(5)).value == 0  # Edge case with negative
    assert Sum(-10).concat(Sum(-5)).value == -15  # Edge case with negative
