# file: pymonet.semigroups.py:1-21
# asked: {"lines": [1, 2, 10, 11, 13, 14, 16, 17, 19, 20, 21], "branches": []}
# gained: {"lines": [1, 2, 10, 11, 13, 14, 16, 17, 19, 20, 21], "branches": []}

import pytest
from pymonet.semigroups import Semigroup

def test_semigroup_init():
    s = Semigroup(5)
    assert s.value == 5

def test_semigroup_eq():
    s1 = Semigroup(5)
    s2 = Semigroup(5)
    s3 = Semigroup(10)
    assert s1 == s2
    assert s1 != s3

def test_semigroup_fold():
    s = Semigroup(5)
    result = s.fold(lambda x: x * 2)
    assert result == 10

def test_semigroup_neutral():
    class TestSemigroup(Semigroup):
        neutral_element = 0  # Define a neutral element for testing

    neutral_instance = TestSemigroup.neutral()
    assert neutral_instance.value == 0
