# file: pymonet.semigroups.py:64-81
# asked: {"lines": [64, 65, 69, 71, 72, 74, 81], "branches": []}
# gained: {"lines": [64, 65, 69, 71, 72, 74, 81], "branches": []}

import pytest
from pymonet.semigroups import One

def test_one_concat_with_true_values():
    a = One(True)
    b = One(True)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'One[value=True]'

def test_one_concat_with_false_and_true_values():
    a = One(False)
    b = One(True)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'One[value=True]'

def test_one_concat_with_true_and_false_values():
    a = One(True)
    b = One(False)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'One[value=True]'

def test_one_concat_with_false_values():
    a = One(False)
    b = One(False)
    result = a.concat(b)
    assert result.value is False
    assert str(result) == 'One[value=False]'
