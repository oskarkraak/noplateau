# file: pymonet.semigroups.py:160-177
# asked: {"lines": [160, 161, 165, 167, 168, 170, 177], "branches": []}
# gained: {"lines": [160, 161, 165, 167, 168, 170, 177], "branches": []}

import pytest
from pymonet.semigroups import Min

def test_min_concat_with_smaller_value():
    min1 = Min(3)
    min2 = Min(5)
    result = min1.concat(min2)
    assert result.value == 3
    assert str(result) == 'Min[value=3]'

def test_min_concat_with_larger_value():
    min1 = Min(7)
    min2 = Min(4)
    result = min1.concat(min2)
    assert result.value == 4
    assert str(result) == 'Min[value=4]'

def test_min_concat_with_equal_value():
    min1 = Min(6)
    min2 = Min(6)
    result = min1.concat(min2)
    assert result.value == 6
    assert str(result) == 'Min[value=6]'
