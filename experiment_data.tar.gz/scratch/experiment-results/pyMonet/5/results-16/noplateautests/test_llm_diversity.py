import pytest
from pymonet.semigroups import Last, Max, Sum, One, Min, Semigroup, First, All

# Tests for Last
def test_last_str():
    last_instance = Last(5)
    assert str(last_instance) == 'Last[value=5]'

def test_last_concat():
    last_instance1 = Last(3)
    last_instance2 = Last(7)
    result = last_instance1.concat(last_instance2)
    assert result.value == 7
    assert isinstance(result, Last)

def test_last_concat_same_value():
    last_instance1 = Last(5)
    last_instance2 = Last(5)
    result = last_instance1.concat(last_instance2)
    assert result.value == 5
    assert isinstance(result, Last)

# Tests for Max
@pytest.fixture
def max_instance_a():
    return Max(3)

@pytest.fixture
def max_instance_b():
    return Max(5)

def test_max_str(max_instance_a):
    assert str(max_instance_a) == 'Max[value=3]'

def test_max_concat_greater(max_instance_a, max_instance_b):
    result = max_instance_a.concat(max_instance_b)
    assert result.value == 5
    assert isinstance(result, Max)

def test_max_concat_lesser(max_instance_a, max_instance_b):
    result = max_instance_b.concat(max_instance_a)
    assert result.value == 5
    assert isinstance(result, Max)

def test_max_concat_equal(max_instance_a):
    equal_instance = Max(3)
    result = max_instance_a.concat(equal_instance)
    assert result.value == 3
    assert isinstance(result, Max)

# Tests for Sum
def test_sum_str():
    sum_instance = Sum(5)
    assert str(sum_instance) == 'Sum[value=5]'

def test_sum_concat():
    sum1 = Sum(3)
    sum2 = Sum(7)
    result = sum1.concat(sum2)
    assert result.value == 10
    assert isinstance(result, Sum)

def test_sum_concat_with_negative():
    sum1 = Sum(-2)
    sum2 = Sum(5)
    result = sum1.concat(sum2)
    assert result.value == 3
    assert isinstance(result, Sum)

def test_sum_concat_with_zero():
    sum1 = Sum(0)
    sum2 = Sum(0)
    result = sum1.concat(sum2)
    assert result.value == 0
    assert isinstance(result, Sum)

# Tests for One
def test_one_concat_with_true_values():
    a = One(True)
    b = One(True)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'One[value=True]'

def test_one_concat_with_false_and_true_values():
    a = One(False)
    b = One(True)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'One[value=True]'

def test_one_concat_with_false_values():
    a = One(False)
    b = One(False)
    result = a.concat(b)
    assert result.value is False
    assert str(result) == 'One[value=False]'

# Tests for Min
def test_min_concat_with_smaller_value():
    min1 = Min(3)
    min2 = Min(5)
    result = min1.concat(min2)
    assert result.value == 3
    assert str(result) == 'Min[value=3]'

def test_min_concat_with_larger_value():
    min1 = Min(7)
    min2 = Min(4)
    result = min1.concat(min2)
    assert result.value == 4
    assert str(result) == 'Min[value=4]'

def test_min_concat_with_equal_value():
    min1 = Min(6)
    min2 = Min(6)
    result = min1.concat(min2)
    assert result.value == 6
    assert str(result) == 'Min[value=6]'

# Tests for Semigroup
def test_semigroup_init():
    semigroup = Semigroup(5)
    assert semigroup.value == 5

def test_semigroup_eq():
    semigroup1 = Semigroup(5)
    semigroup2 = Semigroup(5)
    semigroup3 = Semigroup(10)
    assert semigroup1 == semigroup2
    assert semigroup1 != semigroup3

def test_semigroup_fold():
    semigroup = Semigroup(5)
    result = semigroup.fold(lambda x: x * 2)
    assert result == 10

def test_semigroup_neutral():
    class TestSemigroup(Semigroup):
        neutral_element = 0  # Define a neutral element for testing

    neutral_semigroup = TestSemigroup.neutral()
    assert neutral_semigroup.value == 0

# Tests for First
def test_first_concat():
    first_instance_1 = First(10)
    first_instance_2 = First(20)
    result = first_instance_1.concat(first_instance_2)
    assert result.value == 10
    assert isinstance(result, First)

# Tests for All
@pytest.fixture
def all_instance():
    return All(True)

@pytest.fixture
def all_instance_false():
    return All(False)

def test_all_concat_with_true(all_instance):
    result = all_instance.concat(All(True))
    assert result.value is True

def test_all_concat_with_false(all_instance):
    result = all_instance.concat(All(False))
    assert result.value is False

def test_all_concat_with_false_first(all_instance_false):
    result = all_instance_false.concat(All(True))
    assert result.value is False

def test_all_str_method(all_instance):
    assert str(all_instance) == 'All[value=True]'

def test_all_str_method_false(all_instance_false):
    assert str(all_instance_false) == 'All[value=False]'

