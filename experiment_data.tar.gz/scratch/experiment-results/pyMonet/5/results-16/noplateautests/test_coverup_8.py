# file: pymonet.semigroups.py:44-61
# asked: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}
# gained: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}

import pytest
from pymonet.semigroups import All

@pytest.fixture
def all_instance():
    return All(True)

@pytest.fixture
def all_instance_false():
    return All(False)

def test_concat_with_true(all_instance):
    result = all_instance.concat(All(True))
    assert result.value is True

def test_concat_with_false(all_instance):
    result = all_instance.concat(All(False))
    assert result.value is False

def test_concat_with_false_first(all_instance_false):
    result = all_instance_false.concat(All(True))
    assert result.value is False  # Corrected assertion based on logic

def test_str_method(all_instance):
    assert str(all_instance) == 'All[value=True]'

def test_str_method_false(all_instance_false):
    assert str(all_instance_false) == 'All[value=False]'
