# file: pymonet.semigroups.py:84-99
# asked: {"lines": [84, 85, 89, 90, 92, 99], "branches": []}
# gained: {"lines": [84, 85, 89, 90, 92, 99], "branches": []}

import pytest
from pymonet.semigroups import First

def test_first_str():
    first_instance = First(10)
    assert str(first_instance) == 'Fist[value=10]'

def test_first_concat():
    first_instance_1 = First(10)
    first_instance_2 = First(20)
    result = first_instance_1.concat(first_instance_2)
    assert result.value == 10
    assert isinstance(result, First)

def test_first_concat_with_non_first_instance():
    first_instance = First(10)
    result = first_instance.concat(First(20))
    assert result.value == 10
    assert isinstance(result, First)
