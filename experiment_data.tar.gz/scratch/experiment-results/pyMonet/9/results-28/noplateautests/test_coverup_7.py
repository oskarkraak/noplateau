# file: pymonet.semigroups.py:140-157
# asked: {"lines": [140, 141, 145, 147, 148, 150, 157], "branches": []}
# gained: {"lines": [140, 141, 145, 147, 148, 150, 157], "branches": []}

import pytest
from pymonet.semigroups import Max

def test_max_concat_with_larger_value():
    max1 = Max(5)
    max2 = Max(3)
    result = max1.concat(max2)
    assert result.value == 5
    assert str(result) == 'Max[value=5]'

def test_max_concat_with_smaller_value():
    max1 = Max(2)
    max2 = Max(4)
    result = max1.concat(max2)
    assert result.value == 4
    assert str(result) == 'Max[value=4]'

def test_max_concat_with_equal_value():
    max1 = Max(7)
    max2 = Max(7)
    result = max1.concat(max2)
    assert result.value == 7
    assert str(result) == 'Max[value=7]'

def test_max_concat_with_negative_values():
    max1 = Max(-1)
    max2 = Max(-5)
    result = max1.concat(max2)
    assert result.value == -1
    assert str(result) == 'Max[value=-1]'
