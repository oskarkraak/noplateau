# file: pymonet.semigroups.py:160-177
# asked: {"lines": [160, 161, 165, 167, 168, 170, 177], "branches": []}
# gained: {"lines": [160, 161, 165, 167, 168, 170, 177], "branches": []}

import pytest
from pymonet.semigroups import Min

@pytest.fixture
def min_instance():
    return Min(5)

def test_min_str(min_instance):
    assert str(min_instance) == 'Min[value=5]'

def test_min_concat_with_smaller_value(min_instance):
    other = Min(3)
    result = min_instance.concat(other)
    assert result.value == 3
    assert isinstance(result, Min)

def test_min_concat_with_larger_value(min_instance):
    other = Min(7)
    result = min_instance.concat(other)
    assert result.value == 5
    assert isinstance(result, Min)

def test_min_concat_with_equal_value(min_instance):
    other = Min(5)
    result = min_instance.concat(other)
    assert result.value == 5
    assert isinstance(result, Min)
