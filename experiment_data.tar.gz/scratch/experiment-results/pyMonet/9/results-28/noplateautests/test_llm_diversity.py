import pytest
from pymonet.semigroups import Last, Min, Sum, All, Semigroup, One, Max, First

# Tests for Last
def test_last_str():
    last_instance = Last(5)
    assert str(last_instance) == 'Last[value=5]'

def test_last_concat():
    last_instance1 = Last(10)
    last_instance2 = Last(20)
    result = last_instance1.concat(last_instance2)
    assert isinstance(result, Last)
    assert result.value == 20

def test_last_concat_with_same_value():
    last_instance1 = Last(15)
    last_instance2 = Last(15)
    result = last_instance1.concat(last_instance2)
    assert isinstance(result, Last)
    assert result.value == 15

def test_last_concat_with_none():
    last_instance1 = Last(5)
    last_instance2 = Last(None)
    result = last_instance1.concat(last_instance2)
    assert isinstance(result, Last)
    assert result.value is None

# Tests for Min
@pytest.fixture
def min_instance():
    return Min(5)

def test_min_str(min_instance):
    assert str(min_instance) == 'Min[value=5]'

def test_min_concat_with_smaller_value(min_instance):
    other = Min(3)
    result = min_instance.concat(other)
    assert result.value == 3
    assert isinstance(result, Min)

def test_min_concat_with_larger_value(min_instance):
    other = Min(7)
    result = min_instance.concat(other)
    assert result.value == 5
    assert isinstance(result, Min)

def test_min_concat_with_equal_value(min_instance):
    other = Min(5)
    result = min_instance.concat(other)
    assert result.value == 5
    assert isinstance(result, Min)

# Tests for Sum
@pytest.fixture
def sum_instance():
    return Sum(5)

@pytest.fixture
def another_sum_instance():
    return Sum(10)

def test_sum_str(sum_instance):
    assert str(sum_instance) == 'Sum[value=5]'

def test_sum_concat(sum_instance, another_sum_instance):
    result = sum_instance.concat(another_sum_instance)
    assert result.value == 15
    assert isinstance(result, Sum)

def test_sum_concat_with_zero(sum_instance):
    zero_sum = Sum(0)
    result = sum_instance.concat(zero_sum)
    assert result.value == 5
    assert isinstance(result, Sum)

def test_sum_concat_negative(sum_instance):
    negative_sum = Sum(-3)
    result = sum_instance.concat(negative_sum)
    assert result.value == 2
    assert isinstance(result, Sum)

# Tests for All
def test_all_concat_with_true_values():
    a = All(True)
    b = All(True)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'All[value=True]'

def test_all_concat_with_false_and_true_values():
    a = All(False)
    b = All(True)
    result = a.concat(b)
    assert result.value is False
    assert str(result) == 'All[value=False]'

def test_all_concat_with_false_values():
    a = All(False)
    b = All(False)
    result = a.concat(b)
    assert result.value is False
    assert str(result) == 'All[value=False]'

def test_all_concat_with_neutral_element():
    a = All(True)
    b = All(All.neutral_element)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'All[value=True]'

    c = All(False)
    result = c.concat(b)
    assert result.value is False
    assert str(result) == 'All[value=False]'

# Tests for Semigroup
def test_semigroup_init():
    semigroup = Semigroup(5)
    assert semigroup.value == 5

def test_semigroup_eq():
    semigroup1 = Semigroup(5)
    semigroup2 = Semigroup(5)
    semigroup3 = Semigroup(10)
    assert semigroup1 == semigroup2
    assert semigroup1 != semigroup3

def test_semigroup_fold():
    semigroup = Semigroup(5)
    result = semigroup.fold(lambda x: x * 2)
    assert result == 10

def test_semigroup_neutral():
    Semigroup.neutral_element = 0
    neutral_semigroup = Semigroup.neutral()
    assert neutral_semigroup.value == 0

# Tests for One
def test_one_concat_with_true_values():
    a = One(True)
    b = One(True)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'One[value=True]'

def test_one_concat_with_false_and_true_values():
    a = One(False)
    b = One(True)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'One[value=True]'

def test_one_concat_with_true_and_false_values():
    a = One(True)
    b = One(False)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'One[value=True]'

def test_one_concat_with_false_values():
    a = One(False)
    b = One(False)
    result = a.concat(b)
    assert result.value is False
    assert str(result) == 'One[value=False]'

# Tests for Max
def test_max_concat_with_larger_value():
    max1 = Max(5)
    max2 = Max(3)
    result = max1.concat(max2)
    assert result.value == 5
    assert str(result) == 'Max[value=5]'

def test_max_concat_with_smaller_value():
    max1 = Max(2)
    max2 = Max(4)
    result = max1.concat(max2)
    assert result.value == 4
    assert str(result) == 'Max[value=4]'

def test_max_concat_with_equal_value():
    max1 = Max(7)
    max2 = Max(7)
    result = max1.concat(max2)
    assert result.value == 7
    assert str(result) == 'Max[value=7]'

def test_max_concat_with_negative_values():
    max1 = Max(-1)
    max2 = Max(-5)
    result = max1.concat(max2)
    assert result.value == -1
    assert str(result) == 'Max[value=-1]'

# Tests for First
def test_first_concat():
    first_instance_1 = First(10)
    first_instance_2 = First(20)
    result = first_instance_1.concat(first_instance_2)
    assert result.value == 10
    assert isinstance(result, First)

def test_first_concat_with_same_value():
    first_instance_1 = First(10)
    first_instance_2 = First(10)
    result = first_instance_1.concat(first_instance_2)
    assert result.value == 10
    assert isinstance(result, First)

def test_first_concat_with_none():
    first_instance_1 = First(10)
    first_instance_2 = First(None)
    result = first_instance_1.concat(first_instance_2)
    assert result.value == 10  # Assuming First ignores None
