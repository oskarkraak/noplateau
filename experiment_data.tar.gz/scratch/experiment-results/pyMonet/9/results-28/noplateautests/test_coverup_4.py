# file: pymonet.semigroups.py:44-61
# asked: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}
# gained: {"lines": [44, 45, 49, 51, 52, 54, 61], "branches": []}

import pytest
from pymonet.semigroups import All

def test_all_concat_with_true_values():
    a = All(True)
    b = All(True)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'All[value=True]'

def test_all_concat_with_false_and_true_values():
    a = All(False)
    b = All(True)
    result = a.concat(b)
    assert result.value is False
    assert str(result) == 'All[value=False]'

def test_all_concat_with_false_values():
    a = All(False)
    b = All(False)
    result = a.concat(b)
    assert result.value is False
    assert str(result) == 'All[value=False]'

def test_all_concat_with_neutral_element():
    a = All(True)
    b = All(All.neutral_element)
    result = a.concat(b)
    assert result.value is True
    assert str(result) == 'All[value=True]'

    c = All(False)
    result = c.concat(b)
    assert result.value is False
    assert str(result) == 'All[value=False]'
